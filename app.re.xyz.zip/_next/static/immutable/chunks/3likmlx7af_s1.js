;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="f14866a4-d7fa-c6d2-a8b4-660a289632f4")}catch(e){}}();
(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,328175,e=>{"use strict";var t=e.i(236243),r=e.i(530227),i=e.i(270304),o=e.i(153113),n=e.i(156882);let s=(0,t.s)({message:"",variant:"info",open:!1}),a=(0,o.O)({state:s,subscribeKey:(e,t)=>(0,r.T)(s,e,t),open(e,t){let{debug:r}=n.f.state,{code:o,displayMessage:a,debugMessage:l}=e;if(a&&r&&(s.message=a,s.variant=t,s.open=!0),l){if(!i.f.IS_DEVELOPMENT)return;let e="function"==typeof l?l():l,r=o?{code:o}:void 0;"error"===t?console.error(e,r):"warning"===t?console.warn(e,r):console.info(e,r)}},warn(e,t,r){s.open=!0,s.message=e,s.variant="warning",t&&console.warn(t,r)},close(){s.open=!1,s.message="",s.variant="info"}});e.s(["f",0,a])},186414,815322,e=>{"use strict";e.i(195126);var t=e.i(641449),r=e.i(165520);e.i(775353);var i=e.i(772072);e.i(409804);var o=e.i(874107),n=e.i(468412),s=e.i(285836);let a=s.m`
  button {
    background-color: transparent;
    padding: ${({spacing:e})=>e[1]};
  }

  button:focus-visible {
    box-shadow: 0 0 0 4px ${({tokens:e})=>e.core.foregroundAccent020};
  }

  button[data-variant='accent']:hover:enabled,
  button[data-variant='accent']:focus-visible {
    background-color: ${({tokens:e})=>e.core.foregroundAccent010};
  }

  button[data-variant='primary']:hover:enabled,
  button[data-variant='primary']:focus-visible,
  button[data-variant='secondary']:hover:enabled,
  button[data-variant='secondary']:focus-visible {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  button[data-size='xs'] > wui-icon {
    width: 8px;
    height: 8px;
  }

  button[data-size='sm'] > wui-icon {
    width: 12px;
    height: 12px;
  }

  button[data-size='xs'],
  button[data-size='sm'] {
    border-radius: ${({borderRadius:e})=>e[1]};
  }

  button[data-size='md'],
  button[data-size='lg'] {
    border-radius: ${({borderRadius:e})=>e[2]};
  }

  button[data-size='md'] > wui-icon {
    width: 16px;
    height: 16px;
  }

  button[data-size='lg'] > wui-icon {
    width: 20px;
    height: 20px;
  }

  button:disabled {
    background-color: transparent;
    cursor: not-allowed;
    opacity: 0.5;
  }

  button:hover:not(:disabled) {
    background-color: var(--wui-color-accent-glass-015);
  }

  button:focus-visible:not(:disabled) {
    background-color: var(--wui-color-accent-glass-015);
    box-shadow:
      inset 0 0 0 1px var(--wui-color-accent-100),
      0 0 0 4px var(--wui-color-accent-glass-020);
  }
`;var l=function(e,t,r,i){var o,n=arguments.length,s=n<3?t:null===i?i=Object.getOwnPropertyDescriptor(t,r):i;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,r,i);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(s=(n<3?o(s):n>3?o(t,r,s):o(t,r))||s);return n>3&&s&&Object.defineProperty(t,r,s),s};let c=class extends t.f{constructor(){super(...arguments),this.size="md",this.disabled=!1,this.icon="copy",this.iconColor="default",this.variant="accent"}render(){return r.c`
      <button data-variant=${this.variant} ?disabled=${this.disabled} data-size=${this.size}>
        <wui-icon
          color=${({accent:"accent-primary",primary:"inverse",secondary:"default"})[this.variant]||this.iconColor}
          size=${this.size}
          name=${this.icon}
        ></wui-icon>
      </button>
    `}};c.styles=[o.e,o.j,a],l([(0,i.f)()],c.prototype,"size",void 0),l([(0,i.f)({type:Boolean})],c.prototype,"disabled",void 0),l([(0,i.f)()],c.prototype,"icon",void 0),l([(0,i.f)()],c.prototype,"iconColor",void 0),l([(0,i.f)()],c.prototype,"variant",void 0),c=l([(0,n.f)("wui-icon-link")],c),e.s([],815322),e.s([],186414)},423905,e=>{"use strict";e.i(195126);var t=e.i(641449),r=e.i(165520);e.i(775353);var i=e.i(772072);e.i(783601);var o=e.i(628850);e.i(933810),e.i(422323);var n=e.i(874107),s=e.i(468412),a=e.i(285836);let l=a.m`
  :host {
    width: 100%;
  }

  :host([data-type='primary']) > button {
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
  }

  :host([data-type='secondary']) > button {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: ${({spacing:e})=>e[3]};
    width: 100%;
    border-radius: ${({borderRadius:e})=>e[4]};
    transition:
      background-color ${({durations:e})=>e.lg}
        ${({easings:e})=>e["ease-out-power-2"]},
      scale ${({durations:e})=>e.lg} ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color, scale;
  }

  wui-text {
    text-transform: capitalize;
  }

  wui-image {
    color: ${({tokens:e})=>e.theme.textPrimary};
  }

  @media (hover: hover) {
    :host([data-type='primary']) > button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    }

    :host([data-type='secondary']) > button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    }
  }

  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;var c=function(e,t,r,i){var o,n=arguments.length,s=n<3?t:null===i?i=Object.getOwnPropertyDescriptor(t,r):i;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,r,i);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(s=(n<3?o(s):n>3?o(t,r,s):o(t,r))||s);return n>3&&s&&Object.defineProperty(t,r,s),s};let u=class extends t.f{constructor(){super(...arguments),this.type="primary",this.imageSrc="google",this.imageSize=void 0,this.loading=!1,this.boxColor="foregroundPrimary",this.disabled=!1,this.rightIcon=!0,this.boxed=!0,this.rounded=!1,this.fullSize=!1}render(){return this.dataset.rounded=this.rounded?"true":"false",this.dataset.type=this.type,r.c`
      <button
        ?disabled=${!!this.loading||!!this.disabled}
        data-loading=${this.loading}
        tabindex=${(0,o.f)(this.tabIdx)}
      >
        <wui-flex gap="2" alignItems="center">
          ${this.templateLeftIcon()}
          <wui-flex gap="1">
            <slot></slot>
          </wui-flex>
        </wui-flex>
        ${this.templateRightIcon()}
      </button>
    `}templateLeftIcon(){return this.icon?r.c`<wui-image
        icon=${this.icon}
        iconColor=${(0,o.f)(this.iconColor)}
        ?boxed=${this.boxed}
        ?rounded=${this.rounded}
        boxColor=${this.boxColor}
      ></wui-image>`:r.c`<wui-image
      ?boxed=${this.boxed}
      ?rounded=${this.rounded}
      ?fullSize=${this.fullSize}
      size=${(0,o.f)(this.imageSize)}
      src=${this.imageSrc}
      boxColor=${this.boxColor}
    ></wui-image>`}templateRightIcon(){return this.rightIcon?this.loading?r.c`<wui-loading-spinner size="md" color="accent-primary"></wui-loading-spinner>`:r.c`<wui-icon name="chevronRight" size="lg" color="default"></wui-icon>`:null}};u.styles=[n.e,n.j,l],c([(0,i.f)()],u.prototype,"type",void 0),c([(0,i.f)()],u.prototype,"imageSrc",void 0),c([(0,i.f)()],u.prototype,"imageSize",void 0),c([(0,i.f)()],u.prototype,"icon",void 0),c([(0,i.f)()],u.prototype,"iconColor",void 0),c([(0,i.f)({type:Boolean})],u.prototype,"loading",void 0),c([(0,i.f)()],u.prototype,"tabIdx",void 0),c([(0,i.f)()],u.prototype,"boxColor",void 0),c([(0,i.f)({type:Boolean})],u.prototype,"disabled",void 0),c([(0,i.f)({type:Boolean})],u.prototype,"rightIcon",void 0),c([(0,i.f)({type:Boolean})],u.prototype,"boxed",void 0),c([(0,i.f)({type:Boolean})],u.prototype,"rounded",void 0),c([(0,i.f)({type:Boolean})],u.prototype,"fullSize",void 0),u=c([(0,s.f)("wui-list-item")],u),e.s([],423905)},245813,e=>{"use strict";e.i(195126);var t=e.i(641449),r=e.i(165520);e.i(775353);var i=e.i(772072),o=e.i(503824),n=e.i(639912);let s=r.V`
  <svg fill="none" viewBox="0 0 36 40">
    <path
      d="M15.4 2.1a5.21 5.21 0 0 1 5.2 0l11.61 6.7a5.21 5.21 0 0 1 2.61 4.52v13.4c0 1.87-1 3.59-2.6 4.52l-11.61 6.7c-1.62.93-3.6.93-5.22 0l-11.6-6.7a5.21 5.21 0 0 1-2.61-4.51v-13.4c0-1.87 1-3.6 2.6-4.52L15.4 2.1Z"
    />
  </svg>
`;e.i(409804),e.i(670747);var a=e.i(874107),l=e.i(468412),c=e.i(285836);let u=c.m`
  :host {
    position: relative;
    border-radius: inherit;
    display: flex;
    justify-content: center;
    align-items: center;
    width: var(--local-width);
    height: var(--local-height);
  }

  :host([data-round='true']) {
    background: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: 100%;
    outline: 1px solid ${({tokens:e})=>e.core.glass010};
  }

  svg {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
  }

  svg > path {
    stroke: var(--local-stroke);
  }

  wui-image {
    width: 100%;
    height: 100%;
    -webkit-clip-path: var(--local-path);
    clip-path: var(--local-path);
    background: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  wui-icon {
    transform: translateY(-5%);
    width: var(--local-icon-size);
    height: var(--local-icon-size);
  }
`;var h=function(e,t,r,i){var o,n=arguments.length,s=n<3?t:null===i?i=Object.getOwnPropertyDescriptor(t,r):i;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,r,i);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(s=(n<3?o(s):n>3?o(t,r,s):o(t,r))||s);return n>3&&s&&Object.defineProperty(t,r,s),s};let d=class extends t.f{constructor(){super(...arguments),this.size="md",this.name="uknown",this.networkImagesBySize={sm:s,md:n.f,lg:o.f},this.selected=!1,this.round=!1}render(){return this.round?(this.dataset.round="true",this.style.cssText=`
      --local-width: var(--apkt-spacing-10);
      --local-height: var(--apkt-spacing-10);
      --local-icon-size: var(--apkt-spacing-4);
    `):this.style.cssText=`

      --local-path: var(--apkt-path-network-${this.size});
      --local-width:  var(--apkt-width-network-${this.size});
      --local-height:  var(--apkt-height-network-${this.size});
      --local-icon-size:  var(--apkt-spacing-${({sm:"4",md:"6",lg:"10"})[this.size]});
    `,r.c`${this.templateVisual()} ${this.svgTemplate()} `}svgTemplate(){return this.round?null:this.networkImagesBySize[this.size]}templateVisual(){return this.imageSrc?r.c`<wui-image src=${this.imageSrc} alt=${this.name}></wui-image>`:r.c`<wui-icon size="inherit" color="default" name="networkPlaceholder"></wui-icon>`}};d.styles=[a.e,u],h([(0,i.f)()],d.prototype,"size",void 0),h([(0,i.f)()],d.prototype,"name",void 0),h([(0,i.f)({type:Object})],d.prototype,"networkImagesBySize",void 0),h([(0,i.f)()],d.prototype,"imageSrc",void 0),h([(0,i.f)({type:Boolean})],d.prototype,"selected",void 0),h([(0,i.f)({type:Boolean})],d.prototype,"round",void 0),d=h([(0,l.f)("wui-network-image")],d),e.s([],245813)},457700,e=>{"use strict";e.i(195126);var t=e.i(641449),r=e.i(165520);e.i(775353);var i=e.i(772072);e.i(422323);var o=e.i(874107),n=e.i(468412),s=e.i(285836);let a=s.m`
  :host {
    position: relative;
    display: flex;
    width: 100%;
    height: 1px;
    background-color: ${({tokens:e})=>e.theme.borderPrimary};
    justify-content: center;
    align-items: center;
  }

  :host > wui-text {
    position: absolute;
    padding: 0px 8px;
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color;
  }

  :host([data-bg-color='primary']) > wui-text {
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
  }

  :host([data-bg-color='secondary']) > wui-text {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }
`;var l=function(e,t,r,i){var o,n=arguments.length,s=n<3?t:null===i?i=Object.getOwnPropertyDescriptor(t,r):i;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,r,i);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(s=(n<3?o(s):n>3?o(t,r,s):o(t,r))||s);return n>3&&s&&Object.defineProperty(t,r,s),s};let c=class extends t.f{constructor(){super(...arguments),this.text="",this.bgColor="primary"}render(){return this.dataset.bgColor=this.bgColor,r.c`${this.template()}`}template(){return this.text?r.c`<wui-text variant="md-regular" color="secondary">${this.text}</wui-text>`:null}};c.styles=[o.e,a],l([(0,i.f)()],c.prototype,"text",void 0),l([(0,i.f)()],c.prototype,"bgColor",void 0),c=l([(0,n.f)("wui-separator")],c),e.s([],457700)},210694,e=>{"use strict";e.i(435706),e.s([])},361708,e=>{"use strict";e.i(195126);var t=e.i(641449),r=e.i(165520);e.i(775353);var i=e.i(772072);e.i(783601);var o=e.i(628850);e.i(409804),e.i(670747),e.i(422323),e.i(175988);var n=e.i(874107),s=e.i(381872),a=e.i(468412),l=e.i(285836);let c=l.m`
  button {
    display: flex;
    align-items: center;
    height: 40px;
    padding: ${({spacing:e})=>e[2]};
    border-radius: ${({borderRadius:e})=>e[4]};
    column-gap: ${({spacing:e})=>e[1]};
    background-color: transparent;
    transition: background-color ${({durations:e})=>e.lg}
      ${({easings:e})=>e["ease-out-power-2"]};
    will-change: background-color;
  }

  wui-image,
  .icon-box {
    width: ${({spacing:e})=>e[6]};
    height: ${({spacing:e})=>e[6]};
    border-radius: ${({borderRadius:e})=>e[4]};
  }

  wui-text {
    flex: 1;
  }

  .icon-box {
    position: relative;
  }

  .icon-box[data-active='true'] {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
  }

  .circle {
    position: absolute;
    left: 16px;
    top: 15px;
    width: 8px;
    height: 8px;
    background-color: ${({tokens:e})=>e.core.textSuccess};
    box-shadow: 0 0 0 2px ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: 50%;
  }

  /* -- Hover & Active states ----------------------------------------------------------- */
  @media (hover: hover) {
    button:hover:enabled,
    button:active:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    }
  }
`;var u=function(e,t,r,i){var o,n=arguments.length,s=n<3?t:null===i?i=Object.getOwnPropertyDescriptor(t,r):i;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,r,i);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(s=(n<3?o(s):n>3?o(t,r,s):o(t,r))||s);return n>3&&s&&Object.defineProperty(t,r,s),s};let h=class extends t.f{constructor(){super(...arguments),this.address="",this.profileName="",this.alt="",this.imageSrc="",this.icon=void 0,this.iconSize="md",this.enableGreenCircle=!0,this.loading=!1,this.charsStart=4,this.charsEnd=6}render(){return r.c`
      <button>
        ${this.leftImageTemplate()} ${this.textTemplate()} ${this.rightImageTemplate()}
      </button>
    `}leftImageTemplate(){let e=this.icon?r.c`<wui-icon
          size=${(0,o.f)(this.iconSize)}
          color="default"
          name=${this.icon}
          class="icon"
        ></wui-icon>`:r.c`<wui-image src=${this.imageSrc} alt=${this.alt}></wui-image>`;return r.c`
      <wui-flex
        alignItems="center"
        justifyContent="center"
        class="icon-box"
        data-active=${!!this.icon}
      >
        ${e}
        ${this.enableGreenCircle?r.c`<wui-flex class="circle"></wui-flex>`:null}
      </wui-flex>
    `}textTemplate(){return r.c`
      <wui-text variant="lg-regular" color="primary">
        ${s.f.getTruncateString({string:this.profileName||this.address,charsStart:this.profileName?16:this.charsStart,charsEnd:this.profileName?0:this.charsEnd,truncate:this.profileName?"end":"middle"})}
      </wui-text>
    `}rightImageTemplate(){return r.c`<wui-icon name="chevronBottom" size="sm" color="default"></wui-icon>`}};h.styles=[n.e,n.j,c],u([(0,i.f)()],h.prototype,"address",void 0),u([(0,i.f)()],h.prototype,"profileName",void 0),u([(0,i.f)()],h.prototype,"alt",void 0),u([(0,i.f)()],h.prototype,"imageSrc",void 0),u([(0,i.f)()],h.prototype,"icon",void 0),u([(0,i.f)()],h.prototype,"iconSize",void 0),u([(0,i.f)({type:Boolean})],h.prototype,"enableGreenCircle",void 0),u([(0,i.f)({type:Boolean})],h.prototype,"loading",void 0),u([(0,i.f)({type:Number})],h.prototype,"charsStart",void 0),u([(0,i.f)({type:Number})],h.prototype,"charsEnd",void 0),h=u([(0,a.f)("wui-wallet-switch")],h),e.s([],361708)},503824,e=>{"use strict";e.i(195126);var t=e.i(165520);let r=t.V`<svg width="86" height="96" fill="none">
  <path
    d="M78.3244 18.926L50.1808 2.45078C45.7376 -0.150261 40.2624 -0.150262 35.8192 2.45078L7.6756 18.926C3.23322 21.5266 0.5 26.3301 0.5 31.5248V64.4752C0.5 69.6699 3.23322 74.4734 7.6756 77.074L35.8192 93.5492C40.2624 96.1503 45.7376 96.1503 50.1808 93.5492L78.3244 77.074C82.7668 74.4734 85.5 69.6699 85.5 64.4752V31.5248C85.5 26.3301 82.7668 21.5266 78.3244 18.926Z"
  />
</svg>`;e.s(["f",0,r])},639912,e=>{"use strict";e.i(195126);var t=e.i(165520);let r=t.V`<svg  viewBox="0 0 48 54" fill="none">
  <path
    d="M43.4605 10.7248L28.0485 1.61089C25.5438 0.129705 22.4562 0.129705 19.9515 1.61088L4.53951 10.7248C2.03626 12.2051 0.5 14.9365 0.5 17.886V36.1139C0.5 39.0635 2.03626 41.7949 4.53951 43.2752L19.9515 52.3891C22.4562 53.8703 25.5438 53.8703 28.0485 52.3891L43.4605 43.2752C45.9637 41.7949 47.5 39.0635 47.5 36.114V17.8861C47.5 14.9365 45.9637 12.2051 43.4605 10.7248Z"
  />
</svg>`;e.s(["f",0,r])},435706,e=>{"use strict";e.i(195126);var t=e.i(641449),r=e.i(165520);e.i(775353);var i=e.i(772072);e.i(409804),e.i(670747);var o=e.i(874107),n=e.i(468412);e.i(526597);var s=e.i(285836);let a=s.m`
  :host {
    position: relative;
    background-color: ${({tokens:e})=>e.theme.foregroundTertiary};
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: inherit;
    border-radius: var(--local-border-radius);
  }

  :host([data-image='true']) {
    background-color: transparent;
  }

  :host > wui-flex {
    overflow: hidden;
    border-radius: inherit;
    border-radius: var(--local-border-radius);
  }

  :host([data-size='sm']) {
    width: 32px;
    height: 32px;
  }

  :host([data-size='md']) {
    width: 40px;
    height: 40px;
  }

  :host([data-size='lg']) {
    width: 56px;
    height: 56px;
  }

  :host([name='Extension'])::after {
    border: 1px solid ${({colors:e})=>e.accent010};
  }

  :host([data-wallet-icon='allWallets'])::after {
    border: 1px solid ${({colors:e})=>e.accent010};
  }

  wui-icon[data-parent-size='inherit'] {
    width: 75%;
    height: 75%;
    align-items: center;
  }

  wui-icon {
    color: ${({tokens:e})=>e.theme.iconDefault};
  }

  wui-icon[data-parent-size='sm'] {
    width: 24px;
    height: 24px;
  }

  wui-icon[data-parent-size='md'] {
    width: 32px;
    height: 32px;
  }

  :host > wui-icon-box {
    position: absolute;
    overflow: hidden;
    right: -1px;
    bottom: -2px;
    z-index: 1;
    border: 2px solid ${({tokens:e})=>e.theme.backgroundPrimary};
    padding: 1px;
  }
`;var l=function(e,t,r,i){var o,n=arguments.length,s=n<3?t:null===i?i=Object.getOwnPropertyDescriptor(t,r):i;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,r,i);else for(var a=e.length-1;a>=0;a--)(o=e[a])&&(s=(n<3?o(s):n>3?o(t,r,s):o(t,r))||s);return n>3&&s&&Object.defineProperty(t,r,s),s};let c=class extends t.f{constructor(){super(...arguments),this.size="md",this.name="",this.installed=!1,this.badgeSize="xs"}render(){let e="1";return"lg"===this.size?e="4":"md"===this.size?e="2":"sm"===this.size&&(e="1"),this.style.cssText=`
       --local-border-radius: var(--apkt-borderRadius-${e});
   `,this.dataset.size=this.size,this.imageSrc&&(this.dataset.image="true"),this.walletIcon&&(this.dataset.walletIcon=this.walletIcon),r.c`
      <wui-flex justifyContent="center" alignItems="center"> ${this.templateVisual()} </wui-flex>
    `}templateVisual(){return this.imageSrc?r.c`<wui-image src=${this.imageSrc} alt=${this.name}></wui-image>`:this.walletIcon?r.c`<wui-icon size="md" color="default" name=${this.walletIcon}></wui-icon>`:r.c`<wui-icon
      data-parent-size=${this.size}
      size="inherit"
      color="inherit"
      name="wallet"
    ></wui-icon>`}};c.styles=[o.e,a],l([(0,i.f)()],c.prototype,"size",void 0),l([(0,i.f)()],c.prototype,"name",void 0),l([(0,i.f)()],c.prototype,"imageSrc",void 0),l([(0,i.f)()],c.prototype,"walletIcon",void 0),l([(0,i.f)({type:Boolean})],c.prototype,"installed",void 0),l([(0,i.f)()],c.prototype,"badgeSize",void 0),c=l([(0,n.f)("wui-wallet-image")],c),e.s([],435706)},636807,e=>{"use strict";let t={METMASK_CONNECTOR_NAME:"MetaMask",TRUST_CONNECTOR_NAME:"Trust Wallet",SOLFLARE_CONNECTOR_NAME:"Solflare",PHANTOM_CONNECTOR_NAME:"Phantom",COIN98_CONNECTOR_NAME:"Coin98",MAGIC_EDEN_CONNECTOR_NAME:"Magic Eden",BACKPACK_CONNECTOR_NAME:"Backpack",BITGET_CONNECTOR_NAME:"Bitget Wallet",FRONTIER_CONNECTOR_NAME:"Frontier",XVERSE_CONNECTOR_NAME:"Xverse Wallet",LEATHER_CONNECTOR_NAME:"Leather",OKX_CONNECTOR_NAME:"OKX Wallet",BINANCE_CONNECTOR_NAME:"Binance Wallet",EIP155:e.i(270304).f.CHAIN.EVM,ADD_CHAIN_METHOD:"wallet_addEthereumChain",EIP6963_ANNOUNCE_EVENT:"eip6963:announceProvider",EIP6963_REQUEST_EVENT:"eip6963:requestProvider",CONNECTOR_RDNS_MAP:{coinbaseWallet:"com.coinbase.wallet",coinbaseWalletSDK:"com.coinbase.wallet"},CONNECTOR_TYPE_EXTERNAL:"EXTERNAL",CONNECTOR_TYPE_WALLET_CONNECT:"WALLET_CONNECT",CONNECTOR_TYPE_INJECTED:"INJECTED",CONNECTOR_TYPE_ANNOUNCED:"ANNOUNCED",CONNECTOR_TYPE_AUTH:"AUTH",CONNECTOR_TYPE_MULTI_CHAIN:"MULTI_CHAIN",CONNECTOR_TYPE_W3M_AUTH:"AUTH",getSDKVersionWarningMessage:(e,t)=>`
     @@@@@@@           @@@@@@@@@@@@@@@@@@      
   @@@@@@@@@@@      @@@@@@@@@@@@@@@@@@@@@@@@   
  @@@@@@@@@@@@@    @@@@@@@@@@@@@@@@@@@@@@@@@@  
 @@@@@@@@@@@@@@@  @@@@@@@@@@@@@@@@@@@@@@@@@@@  
 @@@@@@@@@@@@@@@  @@@@@@@@@@@@@@   @@@@@@@@@@@ 
 @@@@@@@@@@@@@@@  @@@@@@@@@@@@@   @@@@@@@@@@@@ 
 @@@@@@@@@@@@@@@  @@@@@@@@@@@@@  @@@@@@@@@@@@@
 @@@@@@@@@@@@@@@  @@@@@@@@@@@@   @@@@@@@@@@@@@    
 @@@@@@   @@@@@@  @@@@@@@@@@@   @@@@@@@@@@@@@@    
 @@@@@@   @@@@@@  @@@@@@@@@@@  @@@@@@@@@@@@@@@ 
 @@@@@@@@@@@@@@@  @@@@@@@@@@   @@@@@@@@@@@@@@@ 
 @@@@@@@@@@@@@@@  @@@@@@@@@@@@@@@@@@@@@@@@@@@  
  @@@@@@@@@@@@@    @@@@@@@@@@@@@@@@@@@@@@@@@@  
   @@@@@@@@@@@      @@@@@@@@@@@@@@@@@@@@@@@@   
      @@@@@            @@@@@@@@@@@@@@@@@@  
      
AppKit SDK version ${e} is outdated. Latest version is ${t}. Please update to the latest version for bug fixes and new features.
            
Changelog: https://github.com/reown-com/appkit/releases
NPM Registry: https://www.npmjs.com/package/@reown/appkit`};e.s(["f",0,t])},645704,e=>{"use strict";var t=e.i(270304),r=e.i(578453),i=e.i(318587),o=e.i(683502),n=e.i(636807);let s={getCaipTokens(e){if(!e)return;let t={};return Object.entries(e).forEach(([e,r])=>{t[`${n.f.EIP155}:${e}`]=r}),t},isLowerCaseMatch:(e,t)=>e?.toLowerCase()===t?.toLowerCase(),getActiveNamespaceConnectedToAuth(){let e=r.f.state.activeChain;return t.f.AUTH_CONNECTOR_SUPPORTED_CHAINS.find(r=>i.f.getConnectorId(r)===t.f.CONNECTOR_ID.AUTH&&r===e)},withRetry({conditionFn:e,intervalMs:t,maxRetries:r}){let i=0;return new Promise(o=>{async function n(){return(i+=1,await e())?o(!0):i>=r?o(!1):(setTimeout(n,t),null)}n()})},userChainIdToChainNamespace(e){if("number"==typeof e)return t.f.CHAIN.EVM;let[r]=e.split(":");return r},getOtherAuthNamespaces:e=>e?t.f.AUTH_CONNECTOR_SUPPORTED_CHAINS.filter(t=>t!==e):[],getConnectorStorageInfo(e,t){let r=o.f.getConnections()[t]??[];return{hasDisconnected:o.f.isConnectorDisconnected(e,t),hasConnected:r.some(t=>s.isLowerCaseMatch(t.connectorId,e))}}};e.s(["f",0,s])},379176,e=>{"use strict";var t={exports:{}};function r(e){try{return JSON.stringify(e)}catch{return'"[Circular]"'}}let i=function(e,t,i){var o=i&&i.stringify||r;if("object"==typeof e&&null!==e){var n=t.length+1;if(1===n)return e;var s=Array(n);s[0]=o(e);for(var a=1;a<n;a++)s[a]=o(t[a]);return s.join(" ")}if("string"!=typeof e)return e;var l=t.length;if(0===l)return e;for(var c="",u=0,h=-1,d=e&&e.length||0,f=0;f<d;){if(37===e.charCodeAt(f)&&f+1<d){switch(h=h>-1?h:0,e.charCodeAt(f+1)){case 100:case 102:if(u>=l||null==t[u])break;h<f&&(c+=e.slice(h,f)),c+=Number(t[u]),h=f+2,f++;break;case 105:if(u>=l||null==t[u])break;h<f&&(c+=e.slice(h,f)),c+=Math.floor(Number(t[u])),h=f+2,f++;break;case 79:case 111:case 106:if(u>=l||void 0===t[u])break;h<f&&(c+=e.slice(h,f));var p=typeof t[u];if("string"===p){c+="'"+t[u]+"'",h=f+2,f++;break}if("function"===p){c+=t[u].name||"<anonymous>",h=f+2,f++;break}c+=o(t[u]),h=f+2,f++;break;case 115:if(u>=l)break;h<f&&(c+=e.slice(h,f)),c+=String(t[u]),h=f+2,f++;break;case 37:h<f&&(c+=e.slice(h,f)),c+="%",h=f+2,f++,u--}++u}++f}return -1===h?e:(h<d&&(c+=e.slice(h)),c)};t.exports=u;let o=function(){function e(e){return"u">typeof e&&e}try{return"u">typeof globalThis||Object.defineProperty(Object.prototype,"globalThis",{get:function(){return delete Object.prototype.globalThis,this.globalThis=this},configurable:!0}),globalThis}catch{return e(self)||e(window)||e(this)||{}}}().console||{};function n(e,t){return"silent"===e?1/0:t.levels.values[e]}let s=Symbol("pino.logFuncs"),a=Symbol("pino.hierarchy"),l={error:"log",fatal:"error",warn:"error",info:"log",debug:"log",trace:"log"};function c(e,t){let r={logger:t,parent:e[a]};t[a]=r}function u(e){var t,r,i;let a,p,g;(e=e||{}).browser=e.browser||{};let v=e.browser.transmit;if(v&&"function"!=typeof v.send)throw Error("pino: transmit option must have a send function");let w=e.browser.write||o;e.browser.write&&(e.browser.asObject=!0);let O=e.serializers||{},x=(t=e.browser.serialize,Array.isArray(t)?t.filter(function(e){return"!stdSerializers.err"!==e}):!0===t&&Object.keys(O)),C=e.browser.serialize;Array.isArray(e.browser.serialize)&&e.browser.serialize.indexOf("!stdSerializers.err")>-1&&(C=!1);let E=Object.keys(e.customLevels||{}),_=["error","fatal","warn","info","debug","trace"].concat(E);"function"==typeof w&&_.forEach(function(e){w[e]=w}),(!1===e.enabled||e.browser.disabled)&&(e.level="silent");let L=e.level||"info",N=Object.create(w);N.log||(N.log=b),a={},_.forEach(e=>{a[e]=w[e]?w[e]:o[e]||o[l[e]||"log"]||b}),N[s]=a,c({},N),Object.defineProperty(N,"levelVal",{get:function(){return n(this.level,this)}}),Object.defineProperty(N,"level",{get:function(){return this._level},set:function(e){if("silent"!==e&&!this.levels.values[e])throw Error("unknown level "+e);this._level=e,h(this,z,N,"error"),h(this,z,N,"fatal"),h(this,z,N,"warn"),h(this,z,N,"info"),h(this,z,N,"debug"),h(this,z,N,"trace"),E.forEach(e=>{h(this,z,N,e)})}});let z={transmit:v,serialize:x,asObject:e.browser.asObject,asObjectBindingsOnly:e.browser.asObjectBindingsOnly,formatters:e.browser.formatters,levels:_,timestamp:"function"==typeof(r=e).timestamp?r.timestamp:!1===r.timestamp?m:y,messageKey:e.messageKey||"msg",onChild:e.onChild||b};function T(t,r,i){if(!r)throw Error("missing bindings for child Pino");i=i||{},x&&r.serializers&&(i.serializers=r.serializers);let o=i.serializers;if(x&&o){var n=Object.assign({},O,o),s=!0===e.browser.serialize?Object.keys(n):x;delete r.serializers,d([r],s,n,this._stdErrSerialize)}function a(e){this._childLevel=(0|e._childLevel)+1,this.bindings=r,n&&(this.serializers=n,this._serialize=s),v&&(this._logEvent=f([].concat(e._logEvent.bindings,r)))}a.prototype=this;let l=new a(this);return c(this,l),l.child=function(...e){return T.call(this,t,...e)},l.level=i.level||this.level,t.onChild(l),l}return p=e.customLevels||{},N.levels={values:Object.assign({},u.levels.values,p),labels:Object.assign({},u.levels.labels,(g={},Object.keys(i=p).forEach(function(e){g[i[e]]=e}),g))},N.level=L,N.isLevelEnabled=function(e){return!!this.levels.values[e]&&this.levels.values[e]>=this.levels.values[this.level]},N.setMaxListeners=N.getMaxListeners=N.emit=N.addListener=N.on=N.prependListener=N.once=N.prependOnceListener=N.removeListener=N.removeAllListeners=N.listeners=N.listenerCount=N.eventNames=N.write=N.flush=b,N.serializers=O,N._serialize=x,N._stdErrSerialize=C,N.child=function(...e){return T.call(this,z,...e)},v&&(N._logEvent=f()),N}function h(e,t,r,l){var c,u,h,p,g,v,m;if(Object.defineProperty(e,l,{value:n(e.level,r)>n(l,r)?b:r[s][l],writable:!0,enumerable:!0,configurable:!0}),e[l]===b){if(!t.transmit)return;let i=n(t.transmit.level||e.level,r);if(n(l,r)<i)return}e[l]=(c=e,u=t,h=r,p=l,g=c[s][p],function(){let e=u.timestamp(),t=Array(arguments.length),r=Object.getPrototypeOf&&Object.getPrototypeOf(this)===o?o:this;for(var s=0;s<t.length;s++)t[s]=arguments[s];var a=!1;if(u.serialize&&(d(t,this._serialize,this.serializers,this._stdErrSerialize),a=!0),u.asObject||u.formatters?g.call(r,...function(e,t,r,o,n){let{level:s,log:a=e=>e}=n.formatters||{},l=r.slice(),c=l[0],u={},h=(0|e._childLevel)+1;if((h<1&&(h=1),o&&(u.time=o),s)?Object.assign(u,s(t,e.levels.values[t])):u.level=e.levels.values[t],n.asObjectBindingsOnly){if(null!==c&&"object"==typeof c)for(;h--&&"object"==typeof l[0];)Object.assign(u,l.shift());return[a(u),...l]}if(null!==c&&"object"==typeof c){for(;h--&&"object"==typeof l[0];)Object.assign(u,l.shift());c=l.length?i(l.shift(),l):void 0}else"string"==typeof c&&(c=i(l.shift(),l));return void 0!==c&&(u[n.messageKey]=c),[a(u)]}(this,p,t,e,u)):g.apply(r,t),u.transmit){let r=u.transmit.level||c._level,i=n(r,h),o=n(p,h);if(o<i)return;!function(e,t,r,i=!1){let o=t.send,n=t.ts,s=t.methodLevel,a=t.methodValue,l=t.val,c=e._logEvent.bindings;i||d(r,e._serialize||Object.keys(e.serializers),e.serializers,void 0===e._stdErrSerialize||e._stdErrSerialize),e._logEvent.ts=n,e._logEvent.messages=r.filter(function(e){return -1===c.indexOf(e)}),e._logEvent.level.label=s,e._logEvent.level.value=a,o(s,e._logEvent,l),e._logEvent=f(c)}(this,{ts:e,methodLevel:p,methodValue:o,transmitLevel:r,transmitValue:h.levels.values[u.transmit.level||c._level],send:u.transmit.send,val:n(c._level,h)},t,a)}});let y=function(e){let t=[];e.bindings&&t.push(e.bindings);let r=e[a];for(;r.parent;)(r=r.parent).logger.bindings&&t.push(r.logger.bindings);return t.reverse()}(e);0!==y.length&&(e[l]=(v=y,m=e[l],function(){return m.apply(this,[...v,...arguments])}))}function d(e,t,r,i){for(let o in e)if(i&&e[o]instanceof Error)e[o]=u.stdSerializers.err(e[o]);else if("object"==typeof e[o]&&!Array.isArray(e[o])&&t)for(let i in e[o])t.indexOf(i)>-1&&i in r&&(e[o][i]=r[i](e[o][i]))}function f(e){return{ts:0,messages:[],bindings:e||[],level:{label:"",value:0}}}function p(e){let t={type:e.constructor.name,msg:e.message,stack:e.stack};for(let r in e)void 0===t[r]&&(t[r]=e[r]);return t}function g(){return{}}function v(e){return e}function b(){}function m(){return!1}function y(){return Date.now()}u.levels={values:{fatal:60,error:50,warn:40,info:30,debug:20,trace:10},labels:{10:"trace",20:"debug",30:"info",40:"warn",50:"error",60:"fatal"}},u.stdSerializers={mapHttpRequest:g,mapHttpResponse:g,wrapRequestSerializer:v,wrapResponseSerializer:v,wrapErrorSerializer:v,req:g,res:g,err:p,errWithCause:p},u.stdTimeFunctions=Object.assign({},{nullTime:m,epochTime:y,unixTime:function(){return Math.round(Date.now()/1e3)},isoTime:function(){return new Date(Date.now()).toISOString()}}),t.exports.default=u,t.exports.pino=u;let w="custom_context";var O=Object.defineProperty,x=(e,t,r)=>{let i;return(i="symbol"!=typeof t?t+"":t)in e?O(e,i,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[i]=r};class C{constructor(e){x(this,"nodeValue"),x(this,"sizeInBytes"),x(this,"next"),this.nodeValue=e,this.sizeInBytes=new TextEncoder().encode(this.nodeValue).length,this.next=null}get value(){return this.nodeValue}get size(){return this.sizeInBytes}}class E{constructor(e){x(this,"lengthInNodes"),x(this,"sizeInBytes"),x(this,"head"),x(this,"tail"),x(this,"maxSizeInBytes"),this.head=null,this.tail=null,this.lengthInNodes=0,this.maxSizeInBytes=e,this.sizeInBytes=0}append(e){let t=new C(e);if(t.size>this.maxSizeInBytes)throw Error(`[LinkedList] Value too big to insert into list: ${e} with size ${t.size}`);for(;this.size+t.size>this.maxSizeInBytes;)this.shift();this.head?this.tail&&(this.tail.next=t):this.head=t,this.tail=t,this.lengthInNodes++,this.sizeInBytes+=t.size}shift(){if(!this.head)return;let e=this.head;this.head=this.head.next,this.head||(this.tail=null),this.lengthInNodes--,this.sizeInBytes-=e.size}toArray(){let e=[],t=this.head;for(;null!==t;)e.push(t.value),t=t.next;return e}get length(){return this.lengthInNodes}get size(){return this.sizeInBytes}toOrderedArray(){return Array.from(this)}[Symbol.iterator](){let e=this.head;return{next:()=>{if(!e)return{done:!0,value:null};let t=e.value;return e=e.next,{done:!1,value:t}}}}}function _(e){return"string"==typeof e?e:JSON.stringify(e,(e,t)=>"bigint"==typeof t?t.toString()+"n":t)||""}var L=Object.defineProperty,N=(e,t,r)=>{let i;return(i="symbol"!=typeof t?t+"":t)in e?L(e,i,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[i]=r};class z{constructor(e,r=1024e3){N(this,"logs"),N(this,"level"),N(this,"levelValue"),N(this,"MAX_LOG_SIZE_IN_BYTES"),this.level=e??"error",this.levelValue=t.exports.levels.values[this.level],this.MAX_LOG_SIZE_IN_BYTES=r,this.logs=new E(this.MAX_LOG_SIZE_IN_BYTES)}forwardToConsole(e,r){r===t.exports.levels.values.error?console.error(e):r===t.exports.levels.values.warn?console.warn(e):r===t.exports.levels.values.debug?console.debug(e):r===t.exports.levels.values.trace?console.trace(e):console.log(e)}appendToLogs(e){this.logs.append(_({timestamp:new Date().toISOString(),log:e}));let t="string"==typeof e?JSON.parse(e).level:e.level;t>=this.levelValue&&this.forwardToConsole(e,t)}getLogs(){return this.logs}clearLogs(){this.logs=new E(this.MAX_LOG_SIZE_IN_BYTES)}getLogArray(){return Array.from(this.logs)}logsToBlob(e){let t=this.getLogArray();return t.push(_({extraMetadata:e})),new Blob(t,{type:"application/json"})}}var T=Object.defineProperty;class ${constructor(e,t=1024e3){var r;let i,o;o=void 0,(i="symbol"!=typeof(r="baseChunkLogger")?r+"":r)in this?T(this,i,{enumerable:!0,configurable:!0,writable:!0,value:o}):this[i]=o,this.baseChunkLogger=new z(e,t)}write(e){this.baseChunkLogger.appendToLogs(e)}getLogs(){return this.baseChunkLogger.getLogs()}clearLogs(){this.baseChunkLogger.clearLogs()}getLogArray(){return this.baseChunkLogger.getLogArray()}logsToBlob(e){return this.baseChunkLogger.logsToBlob(e)}downloadLogsBlobInBrowser(e){let t=URL.createObjectURL(this.logsToBlob(e)),r=document.createElement("a");r.href=t,r.download=`walletconnect-logs-${new Date().toISOString()}.txt`,document.body.appendChild(r),r.click(),document.body.removeChild(r),URL.revokeObjectURL(t)}}var k=Object.defineProperty;class S{constructor(e,t=1024e3){var r;let i,o;o=void 0,(i="symbol"!=typeof(r="baseChunkLogger")?r+"":r)in this?k(this,i,{enumerable:!0,configurable:!0,writable:!0,value:o}):this[i]=o,this.baseChunkLogger=new z(e,t)}write(e){this.baseChunkLogger.appendToLogs(e)}getLogs(){return this.baseChunkLogger.getLogs()}clearLogs(){this.baseChunkLogger.clearLogs()}getLogArray(){return this.baseChunkLogger.getLogArray()}logsToBlob(e){return this.baseChunkLogger.logsToBlob(e)}}var j=Object.defineProperty,I=Object.defineProperties,A=Object.getOwnPropertyDescriptors,R=Object.getOwnPropertySymbols,P=Object.prototype.hasOwnProperty,B=Object.prototype.propertyIsEnumerable,M=(e,t,r)=>t in e?j(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,D=(e,t)=>{for(var r in t||(t={}))P.call(t,r)&&M(e,r,t[r]);if(R)for(var r of R(t))B.call(t,r)&&M(e,r,t[r]);return e};function V(e,t=w){return e[t]||""}e.s(["v",0,function(e,t,r=w){let i=function(e,t,r=w){let i=V(e,r);return i.trim()?`${i}/${t}`:t}(e,t,r);return function(e,t,r=w){return e[r]=t,e}(e.child({context:i}),i,r)},"z",0,function(e){var r,i,o,n,s,a,l;let c,u,h,d,f,p;if("u">typeof e.loggerOverride&&"string"!=typeof e.loggerOverride)return{logger:e.loggerOverride,chunkLoggerController:null};let g=I(D({},e.opts),A({level:"string"==typeof e.loggerOverride?e.loggerOverride:null==(r=e.opts)?void 0:r.level}));return"u">typeof window?(h=new $(null==(o=(i=I(D({},e),A({opts:g}))).opts)?void 0:o.level,i.maxSizeInBytes),{logger:t.exports((c=D({},i.opts),u={level:"trace",browser:I(D({},null==(n=i.opts)?void 0:n.browser),A({write:e=>h.write(e)}))},I(c,A(u)))),chunkLoggerController:h}):(p=new S(null==(a=(s=I(D({},e),A({opts:g}))).opts)?void 0:a.level,s.maxSizeInBytes),{logger:t.exports((d=D({},s.opts),f={level:"trace",browser:I(D({},null==(l=s.opts)?void 0:l.browser),A({write:e=>p.write(e)}))},I(d,A(f))),p),chunkLoggerController:p})},"l",0,function(e){return I(D({},e),A({level:e?.level||"info"}))},"u",0,V])},679877,(e,t,r)=>{"use strict";var i,o="object"==typeof Reflect?Reflect:null,n=o&&"function"==typeof o.apply?o.apply:function(e,t,r){return Function.prototype.apply.call(e,t,r)};i=o&&"function"==typeof o.ownKeys?o.ownKeys:Object.getOwnPropertySymbols?function(e){return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e))}:function(e){return Object.getOwnPropertyNames(e)};var s=Number.isNaN||function(e){return e!=e};function a(){a.init.call(this)}t.exports=a,t.exports.once=function(e,t){return new Promise(function(r,i){var o,n,s;function a(r){e.removeListener(t,l),i(r)}function l(){"function"==typeof e.removeListener&&e.removeListener("error",a),r([].slice.call(arguments))}b(e,t,l,{once:!0}),"error"!==t&&(o=e,n=a,s={once:!0},"function"==typeof o.on&&b(o,"error",n,s))})},a.EventEmitter=a,a.prototype._events=void 0,a.prototype._eventsCount=0,a.prototype._maxListeners=void 0;var l=10;function c(e){if("function"!=typeof e)throw TypeError('The "listener" argument must be of type Function. Received type '+typeof e)}function u(e){return void 0===e._maxListeners?a.defaultMaxListeners:e._maxListeners}function h(e,t,r,i){if(c(r),void 0===(n=e._events)?(n=e._events=Object.create(null),e._eventsCount=0):(void 0!==n.newListener&&(e.emit("newListener",t,r.listener?r.listener:r),n=e._events),s=n[t]),void 0===s)s=n[t]=r,++e._eventsCount;else if("function"==typeof s?s=n[t]=i?[r,s]:[s,r]:i?s.unshift(r):s.push(r),(o=u(e))>0&&s.length>o&&!s.warned){s.warned=!0;var o,n,s,a=Error("Possible EventEmitter memory leak detected. "+s.length+" "+String(t)+" listeners added. Use emitter.setMaxListeners() to increase limit");a.name="MaxListenersExceededWarning",a.emitter=e,a.type=t,a.count=s.length,console&&console.warn&&console.warn(a)}return e}function d(){if(!this.fired)return(this.target.removeListener(this.type,this.wrapFn),this.fired=!0,0==arguments.length)?this.listener.call(this.target):this.listener.apply(this.target,arguments)}function f(e,t,r){var i={fired:!1,wrapFn:void 0,target:e,type:t,listener:r},o=d.bind(i);return o.listener=r,i.wrapFn=o,o}function p(e,t,r){var i=e._events;if(void 0===i)return[];var o=i[t];return void 0===o?[]:"function"==typeof o?r?[o.listener||o]:[o]:r?function(e){for(var t=Array(e.length),r=0;r<t.length;++r)t[r]=e[r].listener||e[r];return t}(o):v(o,o.length)}function g(e){var t=this._events;if(void 0!==t){var r=t[e];if("function"==typeof r)return 1;if(void 0!==r)return r.length}return 0}function v(e,t){for(var r=Array(t),i=0;i<t;++i)r[i]=e[i];return r}function b(e,t,r,i){if("function"==typeof e.on)i.once?e.once(t,r):e.on(t,r);else if("function"==typeof e.addEventListener)e.addEventListener(t,function o(n){i.once&&e.removeEventListener(t,o),r(n)});else throw TypeError('The "emitter" argument must be of type EventEmitter. Received type '+typeof e)}Object.defineProperty(a,"defaultMaxListeners",{enumerable:!0,get:function(){return l},set:function(e){if("number"!=typeof e||e<0||s(e))throw RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received '+e+".");l=e}}),a.init=function(){(void 0===this._events||this._events===Object.getPrototypeOf(this)._events)&&(this._events=Object.create(null),this._eventsCount=0),this._maxListeners=this._maxListeners||void 0},a.prototype.setMaxListeners=function(e){if("number"!=typeof e||e<0||s(e))throw RangeError('The value of "n" is out of range. It must be a non-negative number. Received '+e+".");return this._maxListeners=e,this},a.prototype.getMaxListeners=function(){return u(this)},a.prototype.emit=function(e){for(var t=[],r=1;r<arguments.length;r++)t.push(arguments[r]);var i="error"===e,o=this._events;if(void 0!==o)i=i&&void 0===o.error;else if(!i)return!1;if(i){if(t.length>0&&(s=t[0]),s instanceof Error)throw s;var s,a=Error("Unhandled error."+(s?" ("+s.message+")":""));throw a.context=s,a}var l=o[e];if(void 0===l)return!1;if("function"==typeof l)n(l,this,t);else for(var c=l.length,u=v(l,c),r=0;r<c;++r)n(u[r],this,t);return!0},a.prototype.addListener=function(e,t){return h(this,e,t,!1)},a.prototype.on=a.prototype.addListener,a.prototype.prependListener=function(e,t){return h(this,e,t,!0)},a.prototype.once=function(e,t){return c(t),this.on(e,f(this,e,t)),this},a.prototype.prependOnceListener=function(e,t){return c(t),this.prependListener(e,f(this,e,t)),this},a.prototype.removeListener=function(e,t){var r,i,o,n,s;if(c(t),void 0===(i=this._events)||void 0===(r=i[e]))return this;if(r===t||r.listener===t)0==--this._eventsCount?this._events=Object.create(null):(delete i[e],i.removeListener&&this.emit("removeListener",e,r.listener||t));else if("function"!=typeof r){for(o=-1,n=r.length-1;n>=0;n--)if(r[n]===t||r[n].listener===t){s=r[n].listener,o=n;break}if(o<0)return this;0===o?r.shift():function(e,t){for(;t+1<e.length;t++)e[t]=e[t+1];e.pop()}(r,o),1===r.length&&(i[e]=r[0]),void 0!==i.removeListener&&this.emit("removeListener",e,s||t)}return this},a.prototype.off=a.prototype.removeListener,a.prototype.removeAllListeners=function(e){var t,r,i;if(void 0===(r=this._events))return this;if(void 0===r.removeListener)return 0==arguments.length?(this._events=Object.create(null),this._eventsCount=0):void 0!==r[e]&&(0==--this._eventsCount?this._events=Object.create(null):delete r[e]),this;if(0==arguments.length){var o,n=Object.keys(r);for(i=0;i<n.length;++i)"removeListener"!==(o=n[i])&&this.removeAllListeners(o);return this.removeAllListeners("removeListener"),this._events=Object.create(null),this._eventsCount=0,this}if("function"==typeof(t=r[e]))this.removeListener(e,t);else if(void 0!==t)for(i=t.length-1;i>=0;i--)this.removeListener(e,t[i]);return this},a.prototype.listeners=function(e){return p(this,e,!0)},a.prototype.rawListeners=function(e){return p(this,e,!1)},a.listenerCount=function(e,t){return"function"==typeof e.listenerCount?e.listenerCount(t):g.call(e,t)},a.prototype.listenerCount=g,a.prototype.eventNames=function(){return this._eventsCount>0?i(this._events):[]}}]);

//# debugId=f14866a4-d7fa-c6d2-a8b4-660a289632f4