;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="29094100-2293-2991-d976-9cd80a5bda4a")}catch(e){}}();
(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,199339,17821,e=>{"use strict";var t=e.i(236243),i=e.i(530227),r=e.i(176207),a=e.i(306524),n=e.i(814022),s=e.i(600746),o=e.i(230091),c=e.i(156882);let l={eip155:{native:{assetNamespace:"slip44",assetReference:"60"},defaultTokenNamespace:"erc20"},solana:{native:{assetNamespace:"slip44",assetReference:"501"},defaultTokenNamespace:"token"}},u={56:"714",204:"714"};class d extends Error{}async function p(e,t){let i=function(){let{sdkType:e,sdkVersion:t,projectId:i}=c.f.getSnapshot(),r=new URL("https://rpc.walletconnect.org/v1/json-rpc");return r.searchParams.set("projectId",i),r.searchParams.set("st",e),r.searchParams.set("sv",t),r.searchParams.set("source","fund-wallet"),r.toString()}(),{projectId:r}=c.f.getSnapshot(),a={jsonrpc:"2.0",id:1,method:e,params:{...t||{},projectId:r}},n=await fetch(i,{method:"POST",body:JSON.stringify(a),headers:{"Content-Type":"application/json"}}),s=await n.json();if(s.error)throw new d(s.error.message);return s}async function h(e){return(await p("reown_getExchanges",e)).result}async function f(e){return(await p("reown_getExchangePayUrl",e)).result}async function m(e){return(await p("reown_getExchangeBuyStatus",e)).result}function g(e,t){let{chainNamespace:i,chainId:r}=o.f.parseCaipNetworkId(e),a=l[i];if(!a)throw Error(`Unsupported chain namespace for CAIP-19 formatting: ${i}`);let n=a.native.assetNamespace,s=a.native.assetReference;"native"!==t?(n=a.defaultTokenNamespace,s=t):"eip155"===i&&u[r]&&(s=u[r]);let c=`${i}:${r}`;return`${c}/${n}:${s}`}let y={network:"eip155:8453",asset:"0x833589fcd6edb6e08f4c7c32d4f71b54bda02913",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},w={ethereumETH:{network:"eip155:1",asset:"native",metadata:{name:"Ethereum",symbol:"ETH",decimals:18}},baseETH:{network:"eip155:8453",asset:"native",metadata:{name:"Ethereum",symbol:"ETH",decimals:18}},baseUSDC:y,baseSepoliaETH:{network:"eip155:84532",asset:"native",metadata:{name:"Ethereum",symbol:"ETH",decimals:18}},ethereumUSDC:{network:"eip155:1",asset:"0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},arbitrumUSDC:{network:"eip155:42161",asset:"0xaf88d065e77c8cC2239327C5EDb3A432268e5831",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},polygonUSDC:{network:"eip155:137",asset:"0x2791bca1f2de4661ed88a30c99a7a9449aa84174",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},solanaUSDC:{network:"solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",asset:"EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},ethereumUSDT:{network:"eip155:1",asset:"0xdAC17F958D2ee523a2206206994597C13D831ec7",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},optimismUSDT:{network:"eip155:10",asset:"0x94b008aA00579c1307B0EF2c499aD98a8ce58e58",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},arbitrumUSDT:{network:"eip155:42161",asset:"0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},polygonUSDT:{network:"eip155:137",asset:"0xc2132d05d31c914a87c6611c10748aeb04b58e8f",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},solanaUSDT:{network:"solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",asset:"Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",metadata:{name:"Tether USD",symbol:"USDT",decimals:6}},solanaSOL:{network:"solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",asset:"native",metadata:{name:"Solana",symbol:"SOL",decimals:9}}};function v(e){return Object.values(w).filter(t=>t.network===e)}e.s(["B",0,{network:"eip155:84532",asset:"0x036CbD53842c5426634e7929541eC2318f3dCF7e",metadata:{name:"USD Coin",symbol:"USDC",decimals:6}},"_",0,y,"k",0,g,"W",0,m,"M",0,h,"V",0,f,"O",0,v],17821);var b=e.i(184584),x=e.i(578453),$=e.i(135998),k=e.i(91297);let T={paymentAsset:null,amount:null,tokenAmount:0,priceLoading:!1,error:null,exchanges:[],isLoading:!1,currentPayment:void 0,isPaymentInProgress:!1,paymentId:"",assets:[]},S=(0,t.s)(T),D={state:S,subscribe:e=>(0,t.i)(S,()=>e(S)),subscribeKey:(e,t)=>(0,i.T)(S,e,t),resetState(){Object.assign(S,{...T})},async getAssetsForNetwork(e){let t=v(e),i=await D.getAssetsImageAndPrice(t),r=t.map(e=>{let t="native"===e.asset?(0,a.f)():`${e.network}:${e.asset}`,r=i.find(e=>e.fungibles?.[0]?.address?.toLowerCase()===t.toLowerCase());return{...e,price:r?.fungibles?.[0]?.price||1,metadata:{...e.metadata,iconUrl:r?.fungibles?.[0]?.iconUrl}}});return S.assets=r,r},async getAssetsImageAndPrice(e){let t=e.map(e=>"native"===e.asset?(0,a.f)():`${e.network}:${e.asset}`);return await Promise.all(t.map(e=>b.f.fetchTokenPrice({addresses:[e]})))},getTokenAmount(){if(!S?.paymentAsset?.price)throw Error("Cannot get token price");let e=r.f.bigNumber(S.amount??0).round(8),t=r.f.bigNumber(S.paymentAsset.price).round(8);return e.div(t).round(8).toNumber()},setAmount(e){S.amount=e,S.paymentAsset?.price&&(S.tokenAmount=D.getTokenAmount())},setPaymentAsset(e){S.paymentAsset=e},isPayWithExchangeEnabled:()=>c.f.state.remoteFeatures?.payWithExchange,isPayWithExchangeSupported:()=>D.isPayWithExchangeEnabled()&&x.f.state.activeCaipNetwork&&n.W.PAY_WITH_EXCHANGE_SUPPORTED_CHAIN_NAMESPACES.includes(x.f.state.activeCaipNetwork.chainNamespace),async fetchExchanges(){try{let e=D.isPayWithExchangeSupported();if(!S.paymentAsset||!e){S.exchanges=[],S.isLoading=!1;return}S.isLoading=!0;let t=await h({page:0,asset:g(S.paymentAsset.network,S.paymentAsset.asset),amount:S.amount?.toString()??"0"});S.exchanges=t.exchanges.slice(0,2)}catch(e){throw k.f.showError("Unable to get exchanges"),Error("Unable to get exchanges")}finally{S.isLoading=!1}},async getPayUrl(e,t){try{let i=Number(t.amount),r=await f({exchangeId:e,asset:g(t.network,t.asset),amount:i.toString(),recipient:`${t.network}:${t.recipient}`});return $.f.sendEvent({type:"track",event:"PAY_EXCHANGE_SELECTED",properties:{exchange:{id:e},configuration:{network:t.network,asset:t.asset,recipient:t.recipient,amount:i},currentPayment:{type:"exchange",exchangeId:e},source:"fund-from-exchange",headless:!1}}),r}catch(e){if(e instanceof Error&&e.message.includes("is not supported"))throw Error("Asset not supported");throw Error(e.message)}},async handlePayWithExchange(e){try{let t=x.f.getAccountData()?.address;if(!t)throw Error("No account connected");if(!S.paymentAsset)throw Error("No payment asset selected");let i=s.f.returnOpenHref("","popupWindow","scrollbar=yes,width=480,height=720");if(!i)throw Error("Could not create popup window");S.isPaymentInProgress=!0,S.paymentId=crypto.randomUUID(),S.currentPayment={type:"exchange",exchangeId:e};let{network:r,asset:a}=S.paymentAsset,n={network:r,asset:a,amount:S.tokenAmount,recipient:t},o=await D.getPayUrl(e,n);if(!o){try{i.close()}catch(e){console.error("Unable to close popup window",e)}throw Error("Unable to initiate payment")}S.currentPayment.sessionId=o.sessionId,S.currentPayment.status="IN_PROGRESS",S.currentPayment.exchangeId=e,i.location.href=o.url}catch(e){S.error="Unable to initiate payment",k.f.showError(S.error)}},async waitUntilComplete({exchangeId:e,sessionId:t,paymentId:i,retries:r=20}){let a=await D.getBuyStatus(e,t,i);if("SUCCESS"===a.status||"FAILED"===a.status)return a;if(0===r)throw Error("Unable to get deposit status");return await new Promise(e=>{setTimeout(e,5e3)}),D.waitUntilComplete({exchangeId:e,sessionId:t,paymentId:i,retries:r-1})},async getBuyStatus(e,t,i){try{if(!S.currentPayment)throw Error("No current payment");let r=await m({sessionId:t,exchangeId:e});if(S.currentPayment.status=r.status,"SUCCESS"===r.status||"FAILED"===r.status){let e=x.f.getAccountData()?.address;S.currentPayment.result=r.txHash,S.isPaymentInProgress=!1,$.f.sendEvent({type:"track",event:"SUCCESS"===r.status?"PAY_SUCCESS":"PAY_ERROR",properties:{message:"FAILED"===r.status?s.f.parseError(S.error):void 0,source:"fund-from-exchange",paymentId:i,configuration:{network:S.paymentAsset?.network||"",asset:S.paymentAsset?.asset||"",recipient:e||"",amount:S.amount??0},currentPayment:{type:"exchange",exchangeId:S.currentPayment?.exchangeId,sessionId:S.currentPayment?.sessionId,result:r.txHash}}})}return r}catch(e){return{status:"UNKNOWN",txHash:""}}},reset(){S.currentPayment=void 0,S.isPaymentInProgress=!1,S.paymentId="",S.paymentAsset=null,S.amount=0,S.tokenAmount=0,S.priceLoading=!1,S.error=null,S.exchanges=[],S.isLoading=!1}};e.s(["f",0,D],199339)},987095,e=>{"use strict";e.i(195126);var t,i,r=e.i(641449),a=e.i(165520);e.i(775353);var n=e.i(772072),s=e.i(601908),o=e.i(586295),c=e.i(653462),l=e.i(448036),u=e.i(454090);o.default.extend(l.default),o.default.extend(u.default);let d={...c.default,name:"en-web3-modal",relativeTime:{future:"in %s",past:"%s ago",s:"%d sec",m:"1 min",mm:"%d min",h:"1 hr",hh:"%d hrs",d:"1 d",dd:"%d d",M:"1 mo",MM:"%d mo",y:"1 yr",yy:"%d yr"}},p=["January","February","March","April","May","June","July","August","September","October","November","December"];o.default.locale("en-web3-modal",d);var h=e.i(578453),f=e.i(600746),m=e.i(135998),g=e.i(156882),y=e.i(555544),w=e.i(386398),v=e.i(306524);e.i(186259);var b=e.i(381872);let x=["receive","deposit","borrow","claim"],$=["withdraw","repay","burn"],k={getTransactionGroupTitle(e,t){let i=((e=new Date().toISOString())=>(0,o.default)(e).year())(),r=p[t];return e===i?r:`${r} ${e}`},getTransactionImages(e){let[t]=e;return e?.length>1?e.map(e=>this.getTransactionImage(e)):[this.getTransactionImage(t)]},getTransactionImage:e=>({type:k.getTransactionTransferTokenType(e),url:k.getTransactionImageURL(e)}),getTransactionImageURL(e){let t,i=!!e?.nft_info,r=!!e?.fungible_info;return e&&i?t=e?.nft_info?.content?.preview?.url:e&&r&&(t=e?.fungible_info?.icon?.url),t},getTransactionTransferTokenType:e=>e?.fungible_info?"FUNGIBLE":e?.nft_info?"NFT":void 0,getTransactionDescriptions(e,t){let i=e?.metadata?.operationType,r=t||e?.transfers,a=r&&r.length>0,n=r&&r.length>1,s=a&&r.every(e=>!!e?.fungible_info),[o,c]=r||[],l=this.getTransferDescription(o),u=this.getTransferDescription(c);if(!a)return("send"===i||"receive"===i)&&s?[l=b.f.getTruncateString({string:e?.metadata.sentFrom,charsStart:4,charsEnd:6,truncate:"middle"}),b.f.getTruncateString({string:e?.metadata.sentTo,charsStart:4,charsEnd:6,truncate:"middle"})]:[e.metadata.status];if(n)return r?.map(e=>this.getTransferDescription(e));let d="";return x.includes(i)?d="+":$.includes(i)&&(d="-"),[l=d.concat(l)]},getTransferDescription(e){let t="";return e&&(e?.nft_info?t=e?.nft_info?.name||"-":e?.fungible_info&&(t=this.getFungibleTransferDescription(e)||"-")),t},getFungibleTransferDescription(e){return e?[this.getQuantityFixedValue(e?.quantity.numeric),e?.fungible_info?.symbol].join(" ").trim():null},mergeTransfers(e){if(e?.length<=1)return e;let t=this.filterGasFeeTransfers(e).reduce((e,t)=>{let i=t?.fungible_info?.name,r=e.find(({fungible_info:e,direction:r})=>i&&i===e?.name&&r===t.direction);if(r){let e=Number(r.quantity.numeric)+Number(t.quantity.numeric);r.quantity.numeric=e.toString(),r.value=(r.value||0)+(t.value||0)}else e.push(t);return e},[]),i=t;return t.length>2&&(i=t.sort((e,t)=>(t.value||0)-(e.value||0)).slice(0,2)),i=i.sort((e,t)=>"out"===e.direction&&"in"===t.direction?-1:+("in"===e.direction&&"out"===t.direction))},filterGasFeeTransfers(e){let t=e?.reduce((e,t)=>{let i=t?.fungible_info?.name;return i&&(e[i]||(e[i]=[]),e[i].push(t)),e},{}),i=[];return Object.values(t??{}).forEach(e=>{if(1===e.length){let t=e[0];t&&i.push(t)}else{let t=e.filter(e=>"in"===e.direction),r=e.filter(e=>"out"===e.direction);if(1===t.length&&1===r.length){let a=t[0],n=r[0],s=!1;if(a&&n){let e=Number(a.quantity.numeric),t=Number(n.quantity.numeric);t<.1*e?(i.push(a),s=!0):e<.1*t&&(i.push(n),s=!0)}s||i.push(...e)}else{let t=this.filterGasFeesFromTokenGroup(e);i.push(...t)}}}),e?.forEach(e=>{e?.fungible_info?.name||i.push(e)}),i},filterGasFeesFromTokenGroup(e){if(e.length<=1)return e;let t=e?.map(e=>Number(e.quantity.numeric)),i=Math.max(...t);if(Math.min(...t)<.01*i)return e?.filter(e=>Number(e.quantity.numeric)>=.01*i);let r=e?.filter(e=>"in"===e.direction),a=e?.filter(e=>"out"===e.direction);if(1===r.length&&1===a.length){let e=r[0],t=a[0];if(e&&t){let i=Number(e.quantity.numeric),r=Number(t.quantity.numeric);if(r<.1*i)return[e];if(i<.1*r)return[t]}}return e},getQuantityFixedValue:e=>e?parseFloat(e).toFixed(3):null};var T=e.i(468412);e.i(901015),e.i(290834),e.i(944321),e.i(58624);var S=r;e.i(783601);var D=e.i(628850);e.i(422323);var A=e.i(874107);(t=i||(i={})).approve="approved",t.bought="bought",t.borrow="borrowed",t.burn="burnt",t.cancel="canceled",t.claim="claimed",t.deploy="deployed",t.deposit="deposited",t.execute="executed",t.mint="minted",t.receive="received",t.repay="repaid",t.send="sent",t.sell="sold",t.stake="staked",t.trade="swapped",t.unstake="unstaked",t.withdraw="withdrawn";var C=r;e.i(409804),e.i(670747),e.i(526597);var I=e.i(285836);let _=I.m`
  :host > wui-flex {
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    width: 40px;
    height: 40px;
    box-shadow: inset 0 0 0 1px ${({tokens:e})=>e.core.glass010};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  :host([data-no-images='true']) > wui-flex {
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    border-radius: ${({borderRadius:e})=>e[3]} !important;
  }

  :host > wui-flex wui-image {
    display: block;
  }

  :host > wui-flex,
  :host > wui-flex wui-image,
  .swap-images-container,
  .swap-images-container.nft,
  wui-image.nft {
    border-top-left-radius: var(--local-left-border-radius);
    border-top-right-radius: var(--local-right-border-radius);
    border-bottom-left-radius: var(--local-left-border-radius);
    border-bottom-right-radius: var(--local-right-border-radius);
  }

  .swap-images-container {
    position: relative;
    width: 40px;
    height: 40px;
    overflow: hidden;
  }

  .swap-images-container wui-image:first-child {
    position: absolute;
    width: 40px;
    height: 40px;
    top: 0;
    left: 0%;
    clip-path: inset(0px calc(50% + 2px) 0px 0%);
  }

  .swap-images-container wui-image:last-child {
    clip-path: inset(0px 0px 0px calc(50% + 2px));
  }

  .swap-fallback-container {
    position: absolute;
    inset: 0;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .swap-fallback-container.first {
    clip-path: inset(0px calc(50% + 2px) 0px 0%);
  }

  .swap-fallback-container.last {
    clip-path: inset(0px 0px 0px calc(50% + 2px));
  }

  wui-flex.status-box {
    position: absolute;
    right: 0;
    bottom: 0;
    transform: translate(20%, 20%);
    border-radius: ${({borderRadius:e})=>e[4]};
    background-color: ${({tokens:e})=>e.theme.backgroundPrimary};
    box-shadow: 0 0 0 2px ${({tokens:e})=>e.theme.backgroundPrimary};
    overflow: hidden;
    width: 16px;
    height: 16px;
  }
`;var P=function(e,t,i,r){var a,n=arguments.length,s=n<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,i,r);else for(var o=e.length-1;o>=0;o--)(a=e[o])&&(s=(n<3?a(s):n>3?a(t,i,s):a(t,i))||s);return n>3&&s&&Object.defineProperty(t,i,s),s};let E=class extends C.f{constructor(){super(...arguments),this.images=[],this.secondImage={type:void 0,url:""},this.failedImageUrls=new Set}handleImageError(e){return t=>{t.stopPropagation(),this.failedImageUrls.add(e),this.requestUpdate()}}render(){let[e,t]=this.images;this.images.length||(this.dataset.noImages="true");let i=e?.type==="NFT",r=t?.url?"NFT"===t.type:i;return this.style.cssText=`
    --local-left-border-radius: ${i?"var(--apkt-borderRadius-3)":"var(--apkt-borderRadius-5)"};
    --local-right-border-radius: ${r?"var(--apkt-borderRadius-3)":"var(--apkt-borderRadius-5)"};
    `,a.c`<wui-flex> ${this.templateVisual()} ${this.templateIcon()} </wui-flex>`}templateVisual(){let[e,t]=this.images;return 2===this.images.length&&(e?.url||t?.url)?this.renderSwapImages(e,t):e?.url&&!this.failedImageUrls.has(e.url)?this.renderSingleImage(e):e?.type==="NFT"?this.renderPlaceholderIcon("nftPlaceholder"):this.renderPlaceholderIcon("coinPlaceholder")}renderSwapImages(e,t){return a.c`<div class="swap-images-container">
      ${e?.url?this.renderImageOrFallback(e,"first",!0):null}
      ${t?.url?this.renderImageOrFallback(t,"last",!0):null}
    </div>`}renderSingleImage(e){return this.renderImageOrFallback(e,void 0,!1)}renderImageOrFallback(e,t,i=!1){return e.url?this.failedImageUrls.has(e.url)?i&&t?this.renderFallbackIconInContainer(t):this.renderFallbackIcon():a.c`<wui-image
      src=${e.url}
      alt="Transaction image"
      @onLoadError=${this.handleImageError(e.url)}
    ></wui-image>`:null}renderFallbackIconInContainer(e){return a.c`<div class="swap-fallback-container ${e}">${this.renderFallbackIcon()}</div>`}renderFallbackIcon(){return a.c`<wui-icon
      size="xl"
      weight="regular"
      color="default"
      name="networkPlaceholder"
    ></wui-icon>`}renderPlaceholderIcon(e){return a.c`<wui-icon size="xl" weight="regular" color="default" name=${e}></wui-icon>`}templateIcon(){let e,t="accent-primary";return(e=this.getIcon(),this.status&&(t=this.getStatusColor()),e)?a.c`
      <wui-flex alignItems="center" justifyContent="center" class="status-box">
        <wui-icon-box size="sm" color=${t} icon=${e}></wui-icon-box>
      </wui-flex>
    `:null}getDirectionIcon(){switch(this.direction){case"in":return"arrowBottom";case"out":return"arrowTop";default:return}}getIcon(){return this.onlyDirectionIcon?this.getDirectionIcon():"trade"===this.type?"swapHorizontal":"approve"===this.type?"checkmark":"cancel"===this.type?"close":this.getDirectionIcon()}getStatusColor(){switch(this.status){case"confirmed":return"success";case"failed":return"error";case"pending":return"inverse";default:return"accent-primary"}}};E.styles=[_],P([(0,n.f)()],E.prototype,"type",void 0),P([(0,n.f)()],E.prototype,"status",void 0),P([(0,n.f)()],E.prototype,"direction",void 0),P([(0,n.f)({type:Boolean})],E.prototype,"onlyDirectionIcon",void 0),P([(0,n.f)({type:Array})],E.prototype,"images",void 0),P([(0,n.f)({type:Object})],E.prototype,"secondImage",void 0),P([(0,s.f)()],E.prototype,"failedImageUrls",void 0),E=P([(0,T.f)("wui-transaction-visual")],E);let O=I.m`
  :host {
    width: 100%;
  }

  :host > wui-flex:first-child {
    align-items: center;
    column-gap: ${({spacing:e})=>e[2]};
    padding: ${({spacing:e})=>e[1]} ${({spacing:e})=>e[2]};
    width: 100%;
  }

  :host > wui-flex:first-child wui-text:nth-child(1) {
    text-transform: capitalize;
  }

  wui-transaction-visual {
    width: 40px;
    height: 40px;
  }

  wui-flex {
    flex: 1;
  }

  :host wui-flex wui-flex {
    overflow: hidden;
  }

  :host .description-container wui-text span {
    word-break: break-all;
  }

  :host .description-container wui-text {
    overflow: hidden;
  }

  :host .description-separator-icon {
    margin: 0px 6px;
  }

  :host wui-text > span {
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
  }
`;var U=function(e,t,i,r){var a,n=arguments.length,s=n<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,i,r);else for(var o=e.length-1;o>=0;o--)(a=e[o])&&(s=(n<3?a(s):n>3?a(t,i,s):a(t,i))||s);return n>3&&s&&Object.defineProperty(t,i,s),s};let M=class extends S.f{constructor(){super(...arguments),this.type="approve",this.onlyDirectionIcon=!1,this.images=[]}render(){return a.c`
      <wui-flex>
        <wui-transaction-visual
          .status=${this.status}
          direction=${(0,D.f)(this.direction)}
          type=${this.type}
          .onlyDirectionIcon=${this.onlyDirectionIcon}
          .images=${this.images}
        ></wui-transaction-visual>
        <wui-flex flexDirection="column" gap="1">
          <wui-text variant="lg-medium" color="primary">
            ${i[this.type]||this.type}
          </wui-text>
          <wui-flex class="description-container">
            ${this.templateDescription()} ${this.templateSecondDescription()}
          </wui-flex>
        </wui-flex>
        <wui-text variant="sm-medium" color="secondary"><span>${this.date}</span></wui-text>
      </wui-flex>
    `}templateDescription(){let e=this.descriptions?.[0];return e?a.c`
          <wui-text variant="md-regular" color="secondary">
            <span>${e}</span>
          </wui-text>
        `:null}templateSecondDescription(){let e=this.descriptions?.[1];return e?a.c`
          <wui-icon class="description-separator-icon" size="sm" name="arrowRight"></wui-icon>
          <wui-text variant="md-regular" color="secondary">
            <span>${e}</span>
          </wui-text>
        `:null}};M.styles=[A.e,O],U([(0,n.f)()],M.prototype,"type",void 0),U([(0,n.f)({type:Array})],M.prototype,"descriptions",void 0),U([(0,n.f)()],M.prototype,"date",void 0),U([(0,n.f)({type:Boolean})],M.prototype,"onlyDirectionIcon",void 0),U([(0,n.f)()],M.prototype,"status",void 0),U([(0,n.f)()],M.prototype,"direction",void 0),U([(0,n.f)({type:Array})],M.prototype,"images",void 0),M=U([(0,T.f)("wui-transaction-list-item")],M);var N=r;e.i(110461),e.i(175988);var R=r;let z=I.m`
  wui-flex {
    position: relative;
    display: inline-flex;
    justify-content: center;
    align-items: center;
  }

  wui-image {
    border-radius: ${({borderRadius:e})=>e[128]};
  }

  .fallback-icon {
    color: ${({tokens:e})=>e.theme.iconInverse};
    border-radius: ${({borderRadius:e})=>e[3]};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
  }

  .direction-icon,
  .status-image {
    position: absolute;
    right: 0;
    bottom: 0;
    border-radius: ${({borderRadius:e})=>e[128]};
    border: 2px solid ${({tokens:e})=>e.theme.backgroundPrimary};
  }

  .direction-icon {
    padding: ${({spacing:e})=>e["01"]};
    color: ${({tokens:e})=>e.core.iconSuccess};

    background-color: color-mix(
      in srgb,
      ${({tokens:e})=>e.core.textSuccess} 30%,
      ${({tokens:e})=>e.theme.backgroundPrimary} 70%
    );
  }

  /* -- Sizes --------------------------------------------------- */
  :host([data-size='sm']) > wui-image:not(.status-image),
  :host([data-size='sm']) > wui-flex {
    width: 24px;
    height: 24px;
  }

  :host([data-size='lg']) > wui-image:not(.status-image),
  :host([data-size='lg']) > wui-flex {
    width: 40px;
    height: 40px;
  }

  :host([data-size='sm']) .fallback-icon {
    height: 16px;
    width: 16px;
    padding: ${({spacing:e})=>e[1]};
  }

  :host([data-size='lg']) .fallback-icon {
    height: 32px;
    width: 32px;
    padding: ${({spacing:e})=>e[1]};
  }

  :host([data-size='sm']) .direction-icon,
  :host([data-size='sm']) .status-image {
    transform: translate(40%, 30%);
  }

  :host([data-size='lg']) .direction-icon,
  :host([data-size='lg']) .status-image {
    transform: translate(40%, 10%);
  }

  :host([data-size='sm']) .status-image {
    height: 14px;
    width: 14px;
  }

  :host([data-size='lg']) .status-image {
    height: 20px;
    width: 20px;
  }

  /* -- Crop effects --------------------------------------------------- */
  .swap-crop-left-image,
  .swap-crop-right-image {
    position: absolute;
    top: 0;
    bottom: 0;
  }

  .swap-crop-left-image {
    left: 0;
    clip-path: inset(0px calc(50% + 1.5px) 0px 0%);
  }

  .swap-crop-right-image {
    right: 0;
    clip-path: inset(0px 0px 0px calc(50% + 1.5px));
  }
`;var j=function(e,t,i,r){var a,n=arguments.length,s=n<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,i,r);else for(var o=e.length-1;o>=0;o--)(a=e[o])&&(s=(n<3?a(s):n>3?a(t,i,s):a(t,i))||s);return n>3&&s&&Object.defineProperty(t,i,s),s};let F={sm:"xxs",lg:"md"},L=class extends R.f{constructor(){super(...arguments),this.type="approve",this.size="lg",this.statusImageUrl="",this.images=[]}render(){return a.c`<wui-flex>${this.templateVisual()} ${this.templateIcon()}</wui-flex>`}templateVisual(){switch(this.dataset.size=this.size,this.type){case"trade":return this.swapTemplate();case"fiat":return this.fiatTemplate();case"unknown":return this.unknownTemplate();default:return this.tokenTemplate()}}swapTemplate(){let[e,t]=this.images;return 2===this.images.length&&(e||t)?a.c`
        <wui-image class="swap-crop-left-image" src=${e} alt="Swap image"></wui-image>
        <wui-image class="swap-crop-right-image" src=${t} alt="Swap image"></wui-image>
      `:e?a.c`<wui-image src=${e} alt="Swap image"></wui-image>`:null}fiatTemplate(){return a.c`<wui-icon
      class="fallback-icon"
      size=${F[this.size]}
      name="dollar"
    ></wui-icon>`}unknownTemplate(){return a.c`<wui-icon
      class="fallback-icon"
      size=${F[this.size]}
      name="questionMark"
    ></wui-icon>`}tokenTemplate(){let[e]=this.images;return e?a.c`<wui-image src=${e} alt="Token image"></wui-image> `:a.c`<wui-icon
      class="fallback-icon"
      name=${"nft"===this.type?"image":"coinPlaceholder"}
    ></wui-icon>`}templateIcon(){return this.statusImageUrl?a.c`<wui-image
        class="status-image"
        src=${this.statusImageUrl}
        alt="Status image"
      ></wui-image>`:a.c`<wui-icon
      class="direction-icon"
      size=${F[this.size]}
      name=${this.getTemplateIcon()}
    ></wui-icon>`}getTemplateIcon(){return"trade"===this.type?"arrowClockWise":"arrowBottom"}};L.styles=[z],j([(0,n.f)()],L.prototype,"type",void 0),j([(0,n.f)()],L.prototype,"size",void 0),j([(0,n.f)()],L.prototype,"statusImageUrl",void 0),j([(0,n.f)({type:Array})],L.prototype,"images",void 0),L=j([(0,T.f)("wui-transaction-thumbnail")],L);let Y=I.m`
  :host > wui-flex:first-child {
    gap: ${({spacing:e})=>e[2]};
    padding: ${({spacing:e})=>e[3]};
    width: 100%;
  }

  wui-flex {
    display: flex;
    flex: 1;
  }
`,H=class extends N.f{render(){return a.c`
      <wui-flex alignItems="center" .padding=${["1","2","1","2"]}>
        <wui-shimmer width="40px" height="40px" rounded></wui-shimmer>
        <wui-flex flexDirection="column" gap="1">
          <wui-shimmer width="124px" height="16px" rounded></wui-shimmer>
          <wui-shimmer width="60px" height="14px" rounded></wui-shimmer>
        </wui-flex>
        <wui-shimmer width="24px" height="12px" rounded></wui-shimmer>
      </wui-flex>
    `}};H.styles=[A.e,Y],H=function(e,t,i,r){var a,n=arguments.length,s=n<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,i,r);else for(var o=e.length-1;o>=0;o--)(a=e[o])&&(s=(n<3?a(s):n>3?a(t,i,s):a(t,i))||s);return n>3&&s&&Object.defineProperty(t,i,s),s}([(0,T.f)("wui-transaction-list-item-loader")],H);var B=e.i(164776);let q=I.m`
  :host {
    min-height: 100%;
  }

  .group-container[last-group='true'] {
    padding-bottom: ${({spacing:e})=>e["3"]};
  }

  .contentContainer {
    height: 280px;
  }

  .contentContainer > wui-icon-box {
    width: 40px;
    height: 40px;
    border-radius: ${({borderRadius:e})=>e["3"]};
  }

  .contentContainer > .textContent {
    width: 65%;
  }

  .emptyContainer {
    height: 100%;
  }
`;var G=function(e,t,i,r){var a,n=arguments.length,s=n<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,i,r);else for(var o=e.length-1;o>=0;o--)(a=e[o])&&(s=(n<3?a(s):n>3?a(t,i,s):a(t,i))||s);return n>3&&s&&Object.defineProperty(t,i,s),s};let W="last-transaction",J=class extends r.f{constructor(){super(),this.unsubscribe=[],this.paginationObserver=void 0,this.page="activity",this.caipAddress=h.f.state.activeCaipAddress,this.transactionsByYear=w.f.state.transactionsByYear,this.loading=w.f.state.loading,this.empty=w.f.state.empty,this.next=w.f.state.next,w.f.clearCursor(),this.unsubscribe.push(h.f.subscribeKey("activeCaipAddress",e=>{e&&this.caipAddress!==e&&(w.f.resetTransactions(),w.f.fetchTransactions(e)),this.caipAddress=e}),h.f.subscribeKey("activeCaipNetwork",()=>{this.updateTransactionView()}),w.f.subscribe(e=>{this.transactionsByYear=e.transactionsByYear,this.loading=e.loading,this.empty=e.empty,this.next=e.next}))}firstUpdated(){this.updateTransactionView(),this.createPaginationObserver()}updated(){this.setPaginationObserver()}disconnectedCallback(){this.unsubscribe.forEach(e=>e())}render(){return a.c` ${this.empty?null:this.templateTransactionsByYear()}
    ${this.loading?this.templateLoading():null}
    ${!this.loading&&this.empty?this.templateEmpty():null}`}updateTransactionView(){w.f.resetTransactions(),this.caipAddress&&w.f.fetchTransactions(f.f.getPlainAddress(this.caipAddress))}templateTransactionsByYear(){return Object.keys(this.transactionsByYear).sort().reverse().map(e=>{let t=parseInt(e,10),i=Array(12).fill(null).map((e,i)=>({groupTitle:k.getTransactionGroupTitle(t,i),transactions:this.transactionsByYear[t]?.[i]})).filter(({transactions:e})=>e).reverse();return i.map(({groupTitle:e,transactions:t},r)=>{let n=r===i.length-1;return t?a.c`
          <wui-flex
            flexDirection="column"
            class="group-container"
            last-group="${n?"true":"false"}"
            data-testid="month-indexes"
          >
            <wui-flex
              alignItems="center"
              flexDirection="row"
              .padding=${["2","3","3","3"]}
            >
              <wui-text variant="md-medium" color="secondary" data-testid="group-title">
                ${e}
              </wui-text>
            </wui-flex>
            <wui-flex flexDirection="column" gap="2">
              ${this.templateTransactions(t,n)}
            </wui-flex>
          </wui-flex>
        `:null})})}templateRenderTransaction(e,t){let{date:i,descriptions:r,direction:n,images:s,status:o,type:c,transfers:l,isAllNFT:u}=this.getTransactionListItemProps(e);return a.c`
      <wui-transaction-list-item
        date=${i}
        .direction=${n}
        id=${t&&this.next?W:""}
        status=${o}
        type=${c}
        .images=${s}
        .onlyDirectionIcon=${u||1===l.length}
        .descriptions=${r}
      ></wui-transaction-list-item>
    `}templateTransactions(e,t){return e.map((i,r)=>{let n=t&&r===e.length-1;return a.c`${this.templateRenderTransaction(i,n)}`})}emptyStateActivity(){return a.c`<wui-flex
      class="emptyContainer"
      flexGrow="1"
      flexDirection="column"
      justifyContent="center"
      alignItems="center"
      .padding=${["10","5","10","5"]}
      gap="5"
      data-testid="empty-activity-state"
    >
      <wui-icon-box color="default" icon="wallet" size="xl"></wui-icon-box>
      <wui-flex flexDirection="column" alignItems="center" gap="2">
        <wui-text align="center" variant="lg-medium" color="primary">No Transactions yet</wui-text>
        <wui-text align="center" variant="lg-regular" color="secondary"
          >Start trading on dApps <br />
          to grow your wallet!</wui-text
        >
      </wui-flex>
    </wui-flex>`}emptyStateAccount(){return a.c`<wui-flex
      class="contentContainer"
      alignItems="center"
      justifyContent="center"
      flexDirection="column"
      gap="4"
      data-testid="empty-account-state"
    >
      <wui-icon-box icon="swapHorizontal" size="lg" color="default"></wui-icon-box>
      <wui-flex
        class="textContent"
        gap="2"
        flexDirection="column"
        justifyContent="center"
        flexDirection="column"
      >
        <wui-text variant="md-regular" align="center" color="primary">No activity yet</wui-text>
        <wui-text variant="sm-regular" align="center" color="secondary"
          >Your next transactions will appear here</wui-text
        >
      </wui-flex>
      <wui-link @click=${this.onReceiveClick.bind(this)}>Trade</wui-link>
    </wui-flex>`}templateEmpty(){return"account"===this.page?a.c`${this.emptyStateAccount()}`:a.c`${this.emptyStateActivity()}`}templateLoading(){return"activity"===this.page?a.c` <wui-flex flexDirection="column" width="100%">
        <wui-flex .padding=${["2","3","3","3"]}>
          <wui-shimmer width="70px" height="16px" rounded></wui-shimmer>
        </wui-flex>
        <wui-flex flexDirection="column" gap="2" width="100%">
          ${Array(7).fill(a.c` <wui-transaction-list-item-loader></wui-transaction-list-item-loader> `).map(e=>e)}
        </wui-flex>
      </wui-flex>`:null}onReceiveClick(){y.f.push("WalletReceive")}createPaginationObserver(){let{projectId:e}=g.f.state;this.paginationObserver=new IntersectionObserver(([t])=>{t?.isIntersecting&&!this.loading&&(w.f.fetchTransactions(f.f.getPlainAddress(this.caipAddress)),m.f.sendEvent({type:"track",event:"LOAD_MORE_TRANSACTIONS",properties:{address:f.f.getPlainAddress(this.caipAddress),projectId:e,cursor:this.next,isSmartAccount:(0,v.P)(h.f.state.activeChain)===B.P.ACCOUNT_TYPES.SMART_ACCOUNT}}))},{}),this.setPaginationObserver()}setPaginationObserver(){this.paginationObserver?.disconnect();let e=this.shadowRoot?.querySelector(`#${W}`);e&&this.paginationObserver?.observe(e)}getTransactionListItemProps(e){let t=((e,t="DD MMM")=>(0,o.default)(e).format(t))(e?.metadata?.minedAt),i=k.mergeTransfers(e?.transfers||[]),r=k.getTransactionDescriptions(e,i),a=i?.[0],n=!!a&&i?.every(e=>!!e.nft_info),s=k.getTransactionImages(i);return{date:t,direction:a?.direction,descriptions:r,isAllNFT:n,images:s,status:e.metadata?.status,transfers:i,type:e.metadata?.operationType}}};J.styles=q,G([(0,n.f)()],J.prototype,"page",void 0),G([(0,s.f)()],J.prototype,"caipAddress",void 0),G([(0,s.f)()],J.prototype,"transactionsByYear",void 0),G([(0,s.f)()],J.prototype,"loading",void 0),G([(0,s.f)()],J.prototype,"empty",void 0),G([(0,s.f)()],J.prototype,"next",void 0),J=G([(0,T.f)("w3m-activity-list")],J),e.s([],987095)},252860,e=>{"use strict";e.i(195126);var t=e.i(641449),i=e.i(165520);e.i(775353);var r=e.i(772072);e.i(783601);var a=e.i(628850);e.i(409804),e.i(422323);var n=e.i(874107),s=e.i(468412);e.i(28069);var o=e.i(940697);let c=o.m`
  :host {
    position: relative;
    display: inline-block;
    width: 100%;
  }
`;var l=function(e,t,i,r){var a,n=arguments.length,s=n<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,i,r);else for(var o=e.length-1;o>=0;o--)(a=e[o])&&(s=(n<3?a(s):n>3?a(t,i,s):a(t,i))||s);return n>3&&s&&Object.defineProperty(t,i,s),s};let u=class extends t.f{constructor(){super(...arguments),this.disabled=!1}render(){return i.c`
      <wui-input-text
        type="email"
        placeholder="Email"
        icon="mail"
        size="lg"
        .disabled=${this.disabled}
        .value=${this.value}
        data-testid="wui-email-input"
        tabIdx=${(0,a.f)(this.tabIdx)}
      ></wui-input-text>
      ${this.templateError()}
    `}templateError(){return this.errorMessage?i.c`<wui-text variant="sm-regular" color="error">${this.errorMessage}</wui-text>`:null}};u.styles=[n.e,c],l([(0,r.f)()],u.prototype,"errorMessage",void 0),l([(0,r.f)({type:Boolean})],u.prototype,"disabled",void 0),l([(0,r.f)()],u.prototype,"value",void 0),l([(0,r.f)()],u.prototype,"tabIdx",void 0),u=l([(0,s.f)("wui-email-input")],u),e.s([],252860)},290834,e=>{"use strict";e.i(526597),e.s([])},948541,e=>{"use strict";e.i(28069),e.s([])},987725,e=>{"use strict";e.i(195126);var t=e.i(641449),i=e.i(165520);e.i(775353);var r=e.i(772072),a=e.i(176207);e.i(409804),e.i(670747),e.i(422323),e.i(175988);var n=e.i(874107),s=e.i(468412),o=e.i(285836);let c=o.m`
  :host {
    width: 100%;
  }

  button {
    padding: ${({spacing:e})=>e[3]};
    display: flex;
    gap: ${({spacing:e})=>e[3]};
    justify-content: space-between;
    width: 100%;
    border-radius: ${({borderRadius:e})=>e[4]};
    background-color: transparent;
  }

  @media (hover: hover) {
    button:hover:enabled {
      background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    }
  }

  button:focus-visible:enabled {
    background-color: ${({tokens:e})=>e.theme.foregroundSecondary};
    box-shadow: 0 0 0 4px ${({tokens:e})=>e.core.foregroundAccent040};
  }

  button[data-clickable='false'] {
    pointer-events: none;
    background-color: transparent;
  }

  wui-image,
  wui-icon {
    width: ${({spacing:e})=>e[10]};
    height: ${({spacing:e})=>e[10]};
  }

  wui-image {
    border-radius: ${({borderRadius:e})=>e[16]};
  }

  .token-name-container {
    flex: 1;
  }
`;var l=function(e,t,i,r){var a,n=arguments.length,s=n<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,i,r);else for(var o=e.length-1;o>=0;o--)(a=e[o])&&(s=(n<3?a(s):n>3?a(t,i,s):a(t,i))||s);return n>3&&s&&Object.defineProperty(t,i,s),s};let u=class extends t.f{constructor(){super(...arguments),this.tokenName="",this.tokenImageUrl="",this.tokenValue=0,this.tokenAmount="0.0",this.tokenCurrency="",this.clickable=!1}render(){return i.c`
      <button data-clickable=${String(this.clickable)}>
        <wui-flex gap="2" alignItems="center">
          ${this.visualTemplate()}
          <wui-flex
            flexDirection="column"
            justifyContent="space-between"
            gap="1"
            class="token-name-container"
          >
            <wui-text variant="md-regular" color="primary" lineClamp="1">
              ${this.tokenName}
            </wui-text>
            <wui-text variant="sm-regular-mono" color="secondary">
              ${a.f.formatNumberToLocalString(this.tokenAmount,4)} ${this.tokenCurrency}
            </wui-text>
          </wui-flex>
        </wui-flex>
        <wui-flex
          flexDirection="column"
          justifyContent="space-between"
          gap="1"
          alignItems="flex-end"
          width="auto"
        >
          <wui-text variant="md-regular-mono" color="primary"
            >$${this.tokenValue.toFixed(2)}</wui-text
          >
          <wui-text variant="sm-regular-mono" color="secondary">
            ${a.f.formatNumberToLocalString(this.tokenAmount,4)}
          </wui-text>
        </wui-flex>
      </button>
    `}visualTemplate(){return this.tokenName&&this.tokenImageUrl?i.c`<wui-image alt=${this.tokenName} src=${this.tokenImageUrl}></wui-image>`:i.c`<wui-icon name="coinPlaceholder" color="default"></wui-icon>`}};u.styles=[n.e,n.j,c],l([(0,r.f)()],u.prototype,"tokenName",void 0),l([(0,r.f)()],u.prototype,"tokenImageUrl",void 0),l([(0,r.f)({type:Number})],u.prototype,"tokenValue",void 0),l([(0,r.f)()],u.prototype,"tokenAmount",void 0),l([(0,r.f)()],u.prototype,"tokenCurrency",void 0),l([(0,r.f)({type:Boolean})],u.prototype,"clickable",void 0),u=l([(0,s.f)("wui-list-token")],u),e.s([],987725)},930431,e=>{"use strict";e.i(195126);var t=e.i(641449),i=e.i(165520);e.i(775353);var r=e.i(772072);e.i(670747);var a=e.i(874107),n=e.i(381872),s=e.i(468412),o=e.i(285836);let c=o.m`
  :host {
    display: block;
    width: var(--local-width);
    height: var(--local-height);
    border-radius: ${({borderRadius:e})=>e[16]};
    overflow: hidden;
    position: relative;
  }

  :host([data-variant='generated']) {
    --mixed-local-color-1: var(--local-color-1);
    --mixed-local-color-2: var(--local-color-2);
    --mixed-local-color-3: var(--local-color-3);
    --mixed-local-color-4: var(--local-color-4);
    --mixed-local-color-5: var(--local-color-5);
  }

  :host([data-variant='generated']) {
    background: radial-gradient(
      var(--local-radial-circle),
      #fff 0.52%,
      var(--mixed-local-color-5) 31.25%,
      var(--mixed-local-color-3) 51.56%,
      var(--mixed-local-color-2) 65.63%,
      var(--mixed-local-color-1) 82.29%,
      var(--mixed-local-color-4) 100%
    );
  }

  :host([data-variant='default']) {
    background: radial-gradient(
      75.29% 75.29% at 64.96% 24.36%,
      #fff 0.52%,
      #f5ccfc 31.25%,
      #dba4f5 51.56%,
      #9a8ee8 65.63%,
      #6493da 82.29%,
      #6ebdea 100%
    );
  }
`;var l=function(e,t,i,r){var a,n=arguments.length,s=n<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,i,r);else for(var o=e.length-1;o>=0;o--)(a=e[o])&&(s=(n<3?a(s):n>3?a(t,i,s):a(t,i))||s);return n>3&&s&&Object.defineProperty(t,i,s),s};let u=class extends t.f{constructor(){super(...arguments),this.imageSrc=void 0,this.alt=void 0,this.address=void 0,this.size="xl"}render(){let e={inherit:"inherit",xxs:"3",xs:"5",sm:"6",md:"8",mdl:"8",lg:"10",xl:"16",xxl:"20"};return this.style.cssText=`
    --local-width: var(--apkt-spacing-${e[this.size??"xl"]});
    --local-height: var(--apkt-spacing-${e[this.size??"xl"]});
    `,i.c`${this.visualTemplate()}`}visualTemplate(){if(this.imageSrc)return this.dataset.variant="image",i.c`<wui-image src=${this.imageSrc} alt=${this.alt??"avatar"}></wui-image>`;if(this.address){this.dataset.variant="generated";let e=n.f.generateAvatarColors(this.address);return this.style.cssText+=`
 ${e}`,null}return this.dataset.variant="default",null}};u.styles=[a.e,c],l([(0,r.f)()],u.prototype,"imageSrc",void 0),l([(0,r.f)()],u.prototype,"alt",void 0),l([(0,r.f)()],u.prototype,"address",void 0),l([(0,r.f)()],u.prototype,"size",void 0),u=l([(0,s.f)("wui-avatar")],u),e.s([],930431)},28069,e=>{"use strict";e.i(195126);var t=e.i(641449),i=e.i(165520);e.i(775353);var r=e.i(772072);e.i(783601);var a=e.i(628850);e.i(560589);var n=e.i(979469);e.i(409804),e.i(422323);var s=e.i(874107),o=e.i(468412),c=e.i(285836);let l=c.m`
  :host {
    position: relative;
    width: 100%;
    display: inline-flex;
    flex-direction: column;
    gap: ${({spacing:e})=>e[3]};
    color: ${({tokens:e})=>e.theme.textPrimary};
    caret-color: ${({tokens:e})=>e.core.textAccentPrimary};
  }

  .wui-input-text-container {
    position: relative;
    display: flex;
  }

  input {
    width: 100%;
    border-radius: ${({borderRadius:e})=>e[4]};
    color: inherit;
    background: transparent;
    border: 1px solid ${({tokens:e})=>e.theme.borderPrimary};
    caret-color: ${({tokens:e})=>e.core.textAccentPrimary};
    padding: ${({spacing:e})=>e[3]} ${({spacing:e})=>e[3]}
      ${({spacing:e})=>e[3]} ${({spacing:e})=>e[10]};
    font-size: ${({textSize:e})=>e.large};
    line-height: ${({typography:e})=>e["lg-regular"].lineHeight};
    letter-spacing: ${({typography:e})=>e["lg-regular"].letterSpacing};
    font-weight: ${({fontWeight:e})=>e.regular};
    font-family: ${({fontFamily:e})=>e.regular};
  }

  input[data-size='lg'] {
    padding: ${({spacing:e})=>e[4]} ${({spacing:e})=>e[3]}
      ${({spacing:e})=>e[4]} ${({spacing:e})=>e[10]};
  }

  @media (hover: hover) and (pointer: fine) {
    input:hover:enabled {
      border: 1px solid ${({tokens:e})=>e.theme.borderSecondary};
    }
  }

  input:disabled {
    cursor: unset;
    border: 1px solid ${({tokens:e})=>e.theme.borderPrimary};
  }

  input::placeholder {
    color: ${({tokens:e})=>e.theme.textSecondary};
  }

  input:focus:enabled {
    border: 1px solid ${({tokens:e})=>e.theme.borderSecondary};
    background-color: ${({tokens:e})=>e.theme.foregroundPrimary};
    -webkit-box-shadow: 0px 0px 0px 4px ${({tokens:e})=>e.core.foregroundAccent040};
    -moz-box-shadow: 0px 0px 0px 4px ${({tokens:e})=>e.core.foregroundAccent040};
    box-shadow: 0px 0px 0px 4px ${({tokens:e})=>e.core.foregroundAccent040};
  }

  div.wui-input-text-container:has(input:disabled) {
    opacity: 0.5;
  }

  wui-icon.wui-input-text-left-icon {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    pointer-events: none;
    left: ${({spacing:e})=>e[4]};
    color: ${({tokens:e})=>e.theme.iconDefault};
  }

  button.wui-input-text-submit-button {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: ${({spacing:e})=>e[3]};
    width: 24px;
    height: 24px;
    border: none;
    background: transparent;
    border-radius: ${({borderRadius:e})=>e[2]};
    color: ${({tokens:e})=>e.core.textAccentPrimary};
  }

  button.wui-input-text-submit-button:disabled {
    opacity: 1;
  }

  button.wui-input-text-submit-button.loading wui-icon {
    animation: spin 1s linear infinite;
  }

  button.wui-input-text-submit-button:hover {
    background: ${({tokens:e})=>e.core.foregroundAccent010};
  }

  input:has(+ .wui-input-text-submit-button) {
    padding-right: ${({spacing:e})=>e[12]};
  }

  input[type='number'] {
    -moz-appearance: textfield;
  }

  input[type='search']::-webkit-search-decoration,
  input[type='search']::-webkit-search-cancel-button,
  input[type='search']::-webkit-search-results-button,
  input[type='search']::-webkit-search-results-decoration {
    -webkit-appearance: none;
  }

  /* -- Keyframes --------------------------------------------------- */
  @keyframes spin {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }
`;var u=function(e,t,i,r){var a,n=arguments.length,s=n<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,i):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,i,r);else for(var o=e.length-1;o>=0;o--)(a=e[o])&&(s=(n<3?a(s):n>3?a(t,i,s):a(t,i))||s);return n>3&&s&&Object.defineProperty(t,i,s),s};let d=class extends t.f{constructor(){super(...arguments),this.inputElementRef=(0,n.J)(),this.disabled=!1,this.loading=!1,this.placeholder="",this.type="text",this.value="",this.size="md"}render(){return i.c` <div class="wui-input-text-container">
        ${this.templateLeftIcon()}
        <input
          data-size=${this.size}
          ${(0,n.C)(this.inputElementRef)}
          data-testid="wui-input-text"
          type=${this.type}
          enterkeyhint=${(0,a.f)(this.enterKeyHint)}
          ?disabled=${this.disabled}
          placeholder=${this.placeholder}
          @input=${this.dispatchInputChangeEvent.bind(this)}
          @keydown=${this.onKeyDown}
          .value=${this.value||""}
        />
        ${this.templateSubmitButton()}
        <slot class="wui-input-text-slot"></slot>
      </div>
      ${this.templateError()} ${this.templateWarning()}`}templateLeftIcon(){return this.icon?i.c`<wui-icon
        class="wui-input-text-left-icon"
        size="md"
        data-size=${this.size}
        color="inherit"
        name=${this.icon}
      ></wui-icon>`:null}templateSubmitButton(){return this.onSubmit?i.c`<button
        class="wui-input-text-submit-button ${this.loading?"loading":""}"
        @click=${this.onSubmit?.bind(this)}
        ?disabled=${this.disabled||this.loading}
      >
        ${this.loading?i.c`<wui-icon name="spinner" size="md"></wui-icon>`:i.c`<wui-icon name="chevronRight" size="md"></wui-icon>`}
      </button>`:null}templateError(){return this.errorText?i.c`<wui-text variant="sm-regular" color="error">${this.errorText}</wui-text>`:null}templateWarning(){return this.warningText?i.c`<wui-text variant="sm-regular" color="warning">${this.warningText}</wui-text>`:null}dispatchInputChangeEvent(){this.dispatchEvent(new CustomEvent("inputChange",{detail:this.inputElementRef.value?.value,bubbles:!0,composed:!0}))}};d.styles=[s.e,s.j,l],u([(0,r.f)()],d.prototype,"icon",void 0),u([(0,r.f)({type:Boolean})],d.prototype,"disabled",void 0),u([(0,r.f)({type:Boolean})],d.prototype,"loading",void 0),u([(0,r.f)()],d.prototype,"placeholder",void 0),u([(0,r.f)()],d.prototype,"type",void 0),u([(0,r.f)()],d.prototype,"value",void 0),u([(0,r.f)()],d.prototype,"errorText",void 0),u([(0,r.f)()],d.prototype,"warningText",void 0),u([(0,r.f)()],d.prototype,"onSubmit",void 0),u([(0,r.f)()],d.prototype,"size",void 0),u([(0,r.f)({attribute:!1})],d.prototype,"onKeyDown",void 0),d=u([(0,o.f)("wui-input-text")],d),e.s([],28069)},586295,(e,t,i)=>{e.e,t.exports=function(){"use strict";var e="millisecond",t="second",i="minute",r="hour",a="week",n="month",s="quarter",o="year",c="date",l="Invalid Date",u=/^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,d=/\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,p=function(e,t,i){var r=String(e);return!r||r.length>=t?e:""+Array(t+1-r.length).join(i)+e},h="en",f={};f[h]={name:"en",weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),ordinal:function(e){var t=["th","st","nd","rd"],i=e%100;return"["+e+(t[(i-20)%10]||t[i]||t[0])+"]"}};var m="$isDayjsObject",g=function(e){return e instanceof b||!(!e||!e[m])},y=function e(t,i,r){var a;if(!t)return h;if("string"==typeof t){var n=t.toLowerCase();f[n]&&(a=n),i&&(f[n]=i,a=n);var s=t.split("-");if(!a&&s.length>1)return e(s[0])}else{var o=t.name;f[o]=t,a=o}return!r&&a&&(h=a),a||!r&&h},w=function(e,t){if(g(e))return e.clone();var i="object"==typeof t?t:{};return i.date=e,i.args=arguments,new b(i)},v={s:p,z:function(e){var t=-e.utcOffset(),i=Math.abs(t);return(t<=0?"+":"-")+p(Math.floor(i/60),2,"0")+":"+p(i%60,2,"0")},m:function e(t,i){if(t.date()<i.date())return-e(i,t);var r=12*(i.year()-t.year())+(i.month()-t.month()),a=t.clone().add(r,n),s=i-a<0,o=t.clone().add(r+(s?-1:1),n);return+(-(r+(i-a)/(s?a-o:o-a))||0)},a:function(e){return e<0?Math.ceil(e)||0:Math.floor(e)},p:function(l){return({M:n,y:o,w:a,d:"day",D:c,h:r,m:i,s:t,ms:e,Q:s})[l]||String(l||"").toLowerCase().replace(/s$/,"")},u:function(e){return void 0===e}};v.l=y,v.i=g,v.w=function(e,t){return w(e,{locale:t.$L,utc:t.$u,x:t.$x,$offset:t.$offset})};var b=function(){function p(e){this.$L=y(e.locale,null,!0),this.parse(e),this.$x=this.$x||e.x||{},this[m]=!0}var h=p.prototype;return h.parse=function(e){this.$d=function(e){var t=e.date,i=e.utc;if(null===t)return new Date(0/0);if(v.u(t))return new Date;if(t instanceof Date)return new Date(t);if("string"==typeof t&&!/Z$/i.test(t)){var r=t.match(u);if(r){var a=r[2]-1||0,n=(r[7]||"0").substring(0,3);return i?new Date(Date.UTC(r[1],a,r[3]||1,r[4]||0,r[5]||0,r[6]||0,n)):new Date(r[1],a,r[3]||1,r[4]||0,r[5]||0,r[6]||0,n)}}return new Date(t)}(e),this.init()},h.init=function(){var e=this.$d;this.$y=e.getFullYear(),this.$M=e.getMonth(),this.$D=e.getDate(),this.$W=e.getDay(),this.$H=e.getHours(),this.$m=e.getMinutes(),this.$s=e.getSeconds(),this.$ms=e.getMilliseconds()},h.$utils=function(){return v},h.isValid=function(){return this.$d.toString()!==l},h.isSame=function(e,t){var i=w(e);return this.startOf(t)<=i&&i<=this.endOf(t)},h.isAfter=function(e,t){return w(e)<this.startOf(t)},h.isBefore=function(e,t){return this.endOf(t)<w(e)},h.$g=function(e,t,i){return v.u(e)?this[t]:this.set(i,e)},h.unix=function(){return Math.floor(this.valueOf()/1e3)},h.valueOf=function(){return this.$d.getTime()},h.startOf=function(e,s){var l=this,u=!!v.u(s)||s,d=v.p(e),p=function(e,t){var i=v.w(l.$u?Date.UTC(l.$y,t,e):new Date(l.$y,t,e),l);return u?i:i.endOf("day")},h=function(e,t){return v.w(l.toDate()[e].apply(l.toDate("s"),(u?[0,0,0,0]:[23,59,59,999]).slice(t)),l)},f=this.$W,m=this.$M,g=this.$D,y="set"+(this.$u?"UTC":"");switch(d){case o:return u?p(1,0):p(31,11);case n:return u?p(1,m):p(0,m+1);case a:var w=this.$locale().weekStart||0,b=(f<w?f+7:f)-w;return p(u?g-b:g+(6-b),m);case"day":case c:return h(y+"Hours",0);case r:return h(y+"Minutes",1);case i:return h(y+"Seconds",2);case t:return h(y+"Milliseconds",3);default:return this.clone()}},h.endOf=function(e){return this.startOf(e,!1)},h.$set=function(a,s){var l,u=v.p(a),d="set"+(this.$u?"UTC":""),p=((l={}).day=d+"Date",l[c]=d+"Date",l[n]=d+"Month",l[o]=d+"FullYear",l[r]=d+"Hours",l[i]=d+"Minutes",l[t]=d+"Seconds",l[e]=d+"Milliseconds",l)[u],h="day"===u?this.$D+(s-this.$W):s;if(u===n||u===o){var f=this.clone().set(c,1);f.$d[p](h),f.init(),this.$d=f.set(c,Math.min(this.$D,f.daysInMonth())).$d}else p&&this.$d[p](h);return this.init(),this},h.set=function(e,t){return this.clone().$set(e,t)},h.get=function(e){return this[v.p(e)]()},h.add=function(e,s){var c,l=this;e=Number(e);var u=v.p(s),d=function(t){var i=w(l);return v.w(i.date(i.date()+Math.round(t*e)),l)};if(u===n)return this.set(n,this.$M+e);if(u===o)return this.set(o,this.$y+e);if("day"===u)return d(1);if(u===a)return d(7);var p=((c={})[i]=6e4,c[r]=36e5,c[t]=1e3,c)[u]||1,h=this.$d.getTime()+e*p;return v.w(h,this)},h.subtract=function(e,t){return this.add(-1*e,t)},h.format=function(e){var t=this,i=this.$locale();if(!this.isValid())return i.invalidDate||l;var r=e||"YYYY-MM-DDTHH:mm:ssZ",a=v.z(this),n=this.$H,s=this.$m,o=this.$M,c=i.weekdays,u=i.months,p=i.meridiem,h=function(e,i,a,n){return e&&(e[i]||e(t,r))||a[i].slice(0,n)},f=function(e){return v.s(n%12||12,e,"0")},m=p||function(e,t,i){var r=e<12?"AM":"PM";return i?r.toLowerCase():r};return r.replace(d,function(e,r){return r||function(e){switch(e){case"YY":return String(t.$y).slice(-2);case"YYYY":return v.s(t.$y,4,"0");case"M":return o+1;case"MM":return v.s(o+1,2,"0");case"MMM":return h(i.monthsShort,o,u,3);case"MMMM":return h(u,o);case"D":return t.$D;case"DD":return v.s(t.$D,2,"0");case"d":return String(t.$W);case"dd":return h(i.weekdaysMin,t.$W,c,2);case"ddd":return h(i.weekdaysShort,t.$W,c,3);case"dddd":return c[t.$W];case"H":return String(n);case"HH":return v.s(n,2,"0");case"h":return f(1);case"hh":return f(2);case"a":return m(n,s,!0);case"A":return m(n,s,!1);case"m":return String(s);case"mm":return v.s(s,2,"0");case"s":return String(t.$s);case"ss":return v.s(t.$s,2,"0");case"SSS":return v.s(t.$ms,3,"0");case"Z":return a}return null}(e)||a.replace(":","")})},h.utcOffset=function(){return-(15*Math.round(this.$d.getTimezoneOffset()/15))},h.diff=function(e,c,l){var u,d=this,p=v.p(c),h=w(e),f=(h.utcOffset()-this.utcOffset())*6e4,m=this-h,g=function(){return v.m(d,h)};switch(p){case o:u=g()/12;break;case n:u=g();break;case s:u=g()/3;break;case a:u=(m-f)/6048e5;break;case"day":u=(m-f)/864e5;break;case r:u=m/36e5;break;case i:u=m/6e4;break;case t:u=m/1e3;break;default:u=m}return l?u:v.a(u)},h.daysInMonth=function(){return this.endOf(n).$D},h.$locale=function(){return f[this.$L]},h.locale=function(e,t){if(!e)return this.$L;var i=this.clone(),r=y(e,t,!0);return r&&(i.$L=r),i},h.clone=function(){return v.w(this.$d,this)},h.toDate=function(){return new Date(this.valueOf())},h.toJSON=function(){return this.isValid()?this.toISOString():null},h.toISOString=function(){return this.$d.toISOString()},h.toString=function(){return this.$d.toUTCString()},p}(),x=b.prototype;return w.prototype=x,[["$ms",e],["$s",t],["$m",i],["$H",r],["$W","day"],["$M",n],["$y",o],["$D",c]].forEach(function(e){x[e[1]]=function(t){return this.$g(t,e[0],e[1])}}),w.extend=function(e,t){return e.$i||(e(t,b,w),e.$i=!0),w},w.locale=y,w.isDayjs=g,w.unix=function(e){return w(1e3*e)},w.en=f[h],w.Ls=f,w.p={},w}()},653462,(e,t,i)=>{e.e,t.exports={name:"en",weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),ordinal:function(e){var t=["th","st","nd","rd"],i=e%100;return"["+e+(t[(i-20)%10]||t[i]||t[0])+"]"}}},448036,(e,t,i)=>{e.e,t.exports=function(e,t,i){e=e||{};var r=t.prototype,a={future:"in %s",past:"%s ago",s:"a few seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",M:"a month",MM:"%d months",y:"a year",yy:"%d years"};function n(e,t,i,a){return r.fromToBase(e,t,i,a)}i.en.relativeTime=a,r.fromToBase=function(t,r,n,s,o){for(var c,l,u,d=n.$locale().relativeTime||a,p=e.thresholds||[{l:"s",r:44,d:"second"},{l:"m",r:89},{l:"mm",r:44,d:"minute"},{l:"h",r:89},{l:"hh",r:21,d:"hour"},{l:"d",r:35},{l:"dd",r:25,d:"day"},{l:"M",r:45},{l:"MM",r:10,d:"month"},{l:"y",r:17},{l:"yy",d:"year"}],h=p.length,f=0;f<h;f+=1){var m=p[f];m.d&&(c=s?i(t).diff(n,m.d,!0):n.diff(t,m.d,!0));var g=(e.rounding||Math.round)(Math.abs(c));if(u=c>0,g<=m.r||!m.r){g<=1&&f>0&&(m=p[f-1]);var y=d[m.l];o&&(g=o(""+g)),l="string"==typeof y?y.replace("%d",g):y(g,r,m.l,u);break}}if(r)return l;var w=u?d.future:d.past;return"function"==typeof w?w(l):w.replace("%s",l)},r.to=function(e,t){return n(e,t,this,!0)},r.from=function(e,t){return n(e,t,this)};var s=function(e){return e.$u?i.utc():i()};r.toNow=function(e){return this.to(s(this),e)},r.fromNow=function(e){return this.from(s(this),e)}}},454090,(e,t,i)=>{e.e,t.exports=function(e,t,i){i.updateLocale=function(e,t){var r=i.Ls[e];if(r)return(t?Object.keys(t):[]).forEach(function(e){r[e]=t[e]}),r}}},745759,(e,t,i)=>{"use strict";var r={single_source_shortest_paths:function(e,t,i){var a,n,s,o,c,l,u,d={},p={};p[t]=0;var h=r.PriorityQueue.make();for(h.push(t,0);!h.empty();)for(s in n=(a=h.pop()).value,o=a.cost,c=e[n]||{})c.hasOwnProperty(s)&&(l=o+c[s],u=p[s],(void 0===p[s]||u>l)&&(p[s]=l,h.push(s,l),d[s]=n));if(void 0!==i&&void 0===p[i])throw Error(["Could not find a path from ",t," to ",i,"."].join(""));return d},extract_shortest_path_from_predecessor_list:function(e,t){for(var i=[],r=t;r;)i.push(r),e[r],r=e[r];return i.reverse(),i},find_path:function(e,t,i){var a=r.single_source_shortest_paths(e,t,i);return r.extract_shortest_path_from_predecessor_list(a,i)},PriorityQueue:{make:function(e){var t,i=r.PriorityQueue,a={};for(t in e=e||{},i)i.hasOwnProperty(t)&&(a[t]=i[t]);return a.queue=[],a.sorter=e.sorter||i.default_sorter,a},default_sorter:function(e,t){return e.cost-t.cost},push:function(e,t){this.queue.push({value:e,cost:t}),this.queue.sort(this.sorter)},pop:function(){return this.queue.shift()},empty:function(){return 0===this.queue.length}}};t.exports=r},560589,979469,e=>{"use strict";var t=e.i(165520);let{I:i}=t.e;var r=e.i(972853);let a=(e,t)=>{let i=e._$AN;if(void 0===i)return!1;for(let e of i)e._$AO?.(t,!1),a(e,t);return!0},n=e=>{let t,i;do{if(void 0===(t=e._$AM))break;(i=t._$AN).delete(e),e=t}while(0===i?.size)},s=e=>{for(let t;t=e._$AM;e=t){let i=t._$AN;if(void 0===i)t._$AN=i=new Set;else if(i.has(e))break;i.add(e),l(t)}};function o(e){void 0!==this._$AN?(n(this),this._$AM=e,s(this)):this._$AM=e}function c(e,t=!1,i=0){let r=this._$AH,s=this._$AN;if(void 0!==s&&0!==s.size)if(t)if(Array.isArray(r))for(let e=i;e<r.length;e++)a(r[e],!1),n(r[e]);else null!=r&&(a(r,!1),n(r));else a(this,e)}let l=e=>{e.type==r.x.CHILD&&(e._$AP??=c,e._$AQ??=o)};class u extends r.C{constructor(){super(...arguments),this._$AN=void 0}_$AT(e,t,i){super._$AT(e,t,i),s(this),this.isConnected=e._$AU}_$AO(e,t=!0){e!==this.isConnected&&(this.isConnected=e,e?this.reconnected?.():this.disconnected?.()),t&&(a(this,e),n(this))}setValue(e){if(void 0===this._$Ct.strings)this._$Ct._$AI(e,this);else{let t=[...this._$Ct._$AH];t[this._$Ci]=e,this._$Ct._$AI(t,this,0)}}disconnected(){}reconnected(){}}class d{}let p=new WeakMap,h=(0,r.l)(class extends u{render(e){return t.i}update(e,[i]){let r=i!==this.G;return r&&void 0!==this.G&&this.rt(void 0),(r||this.lt!==this.ct)&&(this.G=i,this.ht=e.options?.host,this.rt(this.ct=e.element)),t.i}rt(e){if(this.isConnected||(e=void 0),"function"==typeof this.G){let t=this.ht??globalThis,i=p.get(t);void 0===i&&(i=new WeakMap,p.set(t,i)),void 0!==i.get(this.G)&&this.G.call(this.ht,void 0),i.set(this.G,e),void 0!==e&&this.G.call(this.ht,e)}else this.G.value=e}get lt(){return"function"==typeof this.G?p.get(this.ht??globalThis)?.get(this.G):this.G?.value}disconnected(){this.lt===this.ct&&this.rt(void 0)}reconnected(){this.rt(this.ct)}});e.s(["J",0,()=>new d,"C",0,h],979469),e.s([],560589)}]);

//# debugId=29094100-2293-2991-d976-9cd80a5bda4a